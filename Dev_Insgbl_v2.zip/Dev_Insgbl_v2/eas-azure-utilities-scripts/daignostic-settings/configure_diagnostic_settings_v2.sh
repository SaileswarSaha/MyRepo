#!/bin/bash

# Parameters for DEV
RESOURCE_GROUP_NAME=$1
WORKSPACE_NAME=$2
RESOURCE_GROUP_SUBSCRIPTION_ID=$3
WORKSPACE_SUBSCRIPTION_ID=$4
LOG_RESOURCE_GROUP_NAME=$5

# Get all resources in the resource group
resources=$(az resource list --resource-group "$RESOURCE_GROUP_NAME" --subscription "$RESOURCE_GROUP_SUBSCRIPTION_ID" --query '[].id' -o tsv)

# Get workspace ID
workspace_id=$(az monitor log-analytics workspace show --resource-group "$LOG_RESOURCE_GROUP_NAME" --workspace-name "$WORKSPACE_NAME" --subscription "$WORKSPACE_SUBSCRIPTION_ID" --query 'id' -o tsv)

# Create diagnostic settings for each resource
for resource_id in $resources; do  
    echo "Configuring diagnostic settings for resource_id : $resource_id..."   
    # Create diagnostic setting
	az monitor diagnostic-settings create --name "ds-$resource_name-publishto-log-eas-shared-mon-dev" --resource $resource_id --workspace $workspace_id --metrics '[{"category": "AllMetrics","enabled": true}]' --export-to-resource-specific true	
done
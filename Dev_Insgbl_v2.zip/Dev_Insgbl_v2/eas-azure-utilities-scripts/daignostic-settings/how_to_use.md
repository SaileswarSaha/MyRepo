# These parameters should match the ones used in the bash script
$resourceGroupName = "rg-aais-dev-eastus-001"
$workspaceName = "log-eas-shared-mon-dev-eastus-001"
$resourceGroupSubscriptionId = "dc8f4966-b393-46f5-ad3c-9b872315d1d0"
$workspaceSubscriptionId = "9f05e3de-d7ff-4d27-a228-f2f48acf42c9"
$logResourceGroupName = "rg-eas-shared-dev-eastus-001"

# Run the bash script with parameters
# This command calls the bash script and passes the parameters defined above
# Ensure the bash script is in the same directory or provide the full path to the script
./create_diagnostic_settings.sh $resourceGroupName $workspaceName $resourceGroupSubscriptionId $workspaceSubscriptionId $logResourceGroupName

# Explanation:
# - $resourceGroupName: The name of the resource group containing the resources you want to configure diagnostic settings for.
# - $workspaceName: The name of the Log Analytics workspace where the diagnostics data will be sent.
# - $resourceGroupSubscriptionId: The subscription ID of the resource group.
# - $workspaceSubscriptionId: The subscription ID of the Log Analytics workspace.
# - $logResourceGroupName: The name of the resource group containing the Log Analytics workspace.

# Ensure the bash script has execute permissions by running the following command in your terminal:
# chmod +x create_diagnostic_settings.sh

# To run the PowerShell script, simply execute it in your PowerShell terminal.
# Make sure you have the Azure CLI installed and logged in to your Azure account.

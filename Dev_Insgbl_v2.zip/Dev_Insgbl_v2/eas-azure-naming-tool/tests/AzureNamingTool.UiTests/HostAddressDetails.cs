﻿namespace AzureNamingTool.UiTests;

public class HostAddressDetails
{
    public string Address { get; set; }
}
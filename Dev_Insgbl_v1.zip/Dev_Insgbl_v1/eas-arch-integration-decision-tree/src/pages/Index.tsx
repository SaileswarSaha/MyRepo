
import { useState } from "react";
import { IntegrationQuestionnaire } from "../components/IntegrationQuestionnaire";
import { IntegrationResults } from "../components/IntegrationResults";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Network, Zap } from "lucide-react";

export interface QuestionnaireResponse {
  dataVolume: string;
  latencyRequirement: string;
  transactionCriticality: string;
  consistencyNeeds: string;
  systemCoupling: string;
  errorHandling: string;
  complianceRequirements: string;
  dataRetention: string;
  scalabilityNeeds: string;
  securityRequirements: string;
  maintenanceWindow: string;
  budgetConstraints: string;
  teamExpertise: string;
  legacyIntegration: string;
  performanceMonitoring: string;
  businessContinuity: string;
}

export interface IntegrationRecommendation {
  pattern: 'real-time' | 'near-time' | 'batch';
  confidence: number;
  primaryTools: string[];
  patterns: string[];
  rationale: string[];
  tradeoffs: {
    pros: string[];
    cons: string[];
  };
  hybridConsiderations?: string[];
}

const Index = () => {
  const [currentStep, setCurrentStep] = useState<'intro' | 'questionnaire' | 'results'>('intro');
  const [responses, setResponses] = useState<QuestionnaireResponse | null>(null);
  const [recommendation, setRecommendation] = useState<IntegrationRecommendation | null>(null);

  const handleQuestionnaireComplete = (data: QuestionnaireResponse) => {
    setResponses(data);
    const result = generateRecommendation(data);
    setRecommendation(result);
    setCurrentStep('results');
  };

  const generateRecommendation = (data: QuestionnaireResponse): IntegrationRecommendation => {
    let realTimeScore = 0;
    let nearTimeScore = 0;
    let batchScore = 0;

    // Data Volume Analysis
    if (data.dataVolume === 'low') realTimeScore += 3;
    if (data.dataVolume === 'medium') nearTimeScore += 2;
    if (data.dataVolume === 'high') batchScore += 3;

    // Latency Requirements
    if (data.latencyRequirement === 'immediate') realTimeScore += 4;
    if (data.latencyRequirement === 'seconds') nearTimeScore += 3;
    if (data.latencyRequirement === 'minutes' || data.latencyRequirement === 'hours') batchScore += 3;

    // Transaction Criticality
    if (data.transactionCriticality === 'mission-critical') realTimeScore += 3;
    if (data.transactionCriticality === 'business-critical') nearTimeScore += 2;
    if (data.transactionCriticality === 'non-critical') batchScore += 2;

    // System Coupling Preferences
    if (data.systemCoupling === 'tight') realTimeScore += 2;
    if (data.systemCoupling === 'loose') nearTimeScore += 3;
    if (data.systemCoupling === 'independent') batchScore += 2;

    // Error Handling
    if (data.errorHandling === 'immediate') realTimeScore += 2;
    if (data.errorHandling === 'resilient') nearTimeScore += 3;
    if (data.errorHandling === 'retry-batch') batchScore += 2;

    // Budget Constraints
    if (data.budgetConstraints === 'high') realTimeScore += 1;
    if (data.budgetConstraints === 'medium') nearTimeScore += 2;
    if (data.budgetConstraints === 'low') batchScore += 3;

    // Determine winning pattern
    const scores = [
      { pattern: 'real-time' as const, score: realTimeScore },
      { pattern: 'near-time' as const, score: nearTimeScore },
      { pattern: 'batch' as const, score: batchScore }
    ];

    const winner = scores.reduce((prev, current) => 
      current.score > prev.score ? current : prev
    );

    const confidence = Math.min(95, Math.max(60, (winner.score / 20) * 100));

    // Generate specific recommendations based on pattern
    if (winner.pattern === 'real-time') {
      return {
        pattern: 'real-time',
        confidence,
        primaryTools: ['Azure API Management', 'Azure Logic Apps', 'Azure Functions', 'MuleSoft Anypoint'],
        patterns: ['API Gateway', 'Request/Response', 'Synchronous Orchestration', 'Circuit Breaker'],
        rationale: [
          'Low-latency requirements demand immediate response capabilities',
          'Mission-critical transactions require synchronous processing',
          'Tight coupling acceptable for real-time data consistency',
          'Immediate error handling and feedback essential'
        ],
        tradeoffs: {
          pros: ['Immediate data consistency', 'Real-time error handling', 'Simplified debugging', 'Predictable performance'],
          cons: ['Higher infrastructure costs', 'Increased system coupling', 'Scalability challenges', 'Single point of failure risks']
        },
        hybridConsiderations: ['Consider async fallback for non-critical operations', 'Implement caching layers for performance']
      };
    } else if (winner.pattern === 'near-time') {
      return {
        pattern: 'near-time',
        confidence,
        primaryTools: ['Azure Event Grid', 'Azure Service Bus', 'Azure Logic Apps (Event-driven)', 'Apache Kafka'],
        patterns: ['Publish/Subscribe', 'Event Sourcing', 'Message Queuing', 'Event-driven Architecture'],
        rationale: [
          'Event-driven architecture provides optimal decoupling',
          'Asynchronous processing handles variable loads effectively',
          'Message durability ensures reliable delivery',
          'Scalable architecture supports growth requirements'
        ],
        tradeoffs: {
          pros: ['Excellent scalability', 'System decoupling', 'Fault tolerance', 'Cost-effective at scale'],
          cons: ['Eventual consistency challenges', 'Complex debugging', 'Message ordering complexity', 'Monitoring overhead']
        },
        hybridConsiderations: ['Implement dead letter queues for error handling', 'Consider real-time for critical path operations']
      };
    } else {
      return {
        pattern: 'batch',
        confidence,
        primaryTools: ['Azure Data Factory', 'Azure Synapse Analytics', 'SQL Server Integration Services', 'Informatica PowerCenter'],
        patterns: ['ETL/ELT', 'Bulk Data Transfer', 'Scheduled Processing', 'Data Pipeline'],
        rationale: [
          'High-volume data processing optimized for throughput',
          'Scheduled maintenance windows align with batch operations',
          'Cost-effective for large dataset migrations',
          'Simplified error handling and recovery processes'
        ],
        tradeoffs: {
          pros: ['Cost-effective for large volumes', 'Simplified error recovery', 'Optimized throughput', 'Resource efficiency'],
          cons: ['Delayed data availability', 'Complex dependency management', 'Limited real-time insights', 'Batch window constraints']
        },
        hybridConsiderations: ['Consider near-time for urgent notifications', 'Implement incremental loading strategies']
      };
    }
  };

  const resetQuestionnaire = () => {
    setCurrentStep('intro');
    setResponses(null);
    setRecommendation(null);
  };

  if (currentStep === 'questionnaire') {
    return <IntegrationQuestionnaire onComplete={handleQuestionnaireComplete} />;
  }

  if (currentStep === 'results' && recommendation) {
    return <IntegrationResults recommendation={recommendation} onReset={resetQuestionnaire} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-600 p-4 rounded-full">
              <Network className="h-12 w-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Enterprise Integration Decision Tree
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Navigate complex integration decisions with confidence. Our expert-designed questionnaire 
            analyzes your requirements and recommends optimal integration patterns, tools, and architectures 
            for your enterprise application landscape.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="border-2 hover:border-blue-200 transition-colors">
            <CardHeader className="text-center">
              <div className="mx-auto bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mb-3">
                <Zap className="h-6 w-6 text-green-600" />
              </div>
              <CardTitle className="text-green-700">Real-Time Integration</CardTitle>
              <CardDescription>
                API Gateway • Orchestration • Synchronous Processing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Azure API Management</li>
                <li>• Logic Apps Orchestration</li>
                <li>• Function Apps (Serverless)</li>
                <li>• MuleSoft Process APIs</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-blue-200 transition-colors">
            <CardHeader className="text-center">
              <div className="mx-auto bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-3">
                <Network className="h-6 w-6 text-blue-600" />
              </div>
              <CardTitle className="text-blue-700">Near-Time Integration</CardTitle>
              <CardDescription>
                Event-Driven • Pub/Sub • Message Queuing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Azure Event Grid</li>
                <li>• Service Bus Messaging</li>
                <li>• Event Sourcing Patterns</li>
                <li>• Apache Kafka Streams</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-blue-200 transition-colors">
            <CardHeader className="text-center">
              <div className="mx-auto bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-3">
                <Building2 className="h-6 w-6 text-purple-600" />
              </div>
              <CardTitle className="text-purple-700">Batch Integration</CardTitle>
              <CardDescription>
                ETL/ELT • Scheduled Processing • High-Volume
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Azure Data Factory</li>
                <li>• Synapse Analytics</li>
                <li>• SSIS Packages</li>
                <li>• Informatica PowerCenter</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Ready to Find Your Optimal Integration Approach?</CardTitle>
              <CardDescription>
                Answer our comprehensive questionnaire designed by enterprise architects 
                to receive personalized recommendations for your integration needs.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <button
                onClick={() => setCurrentStep('questionnaire')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors inline-flex items-center gap-2"
              >
                <Network className="h-5 w-5" />
                Start Assessment
              </button>
              <p className="text-sm text-gray-500 mt-3">
                15+ expert questions • 5-10 minutes • Detailed recommendations
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Index;

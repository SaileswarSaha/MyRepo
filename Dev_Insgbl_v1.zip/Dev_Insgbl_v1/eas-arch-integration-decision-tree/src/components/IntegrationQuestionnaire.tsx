
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, CheckCircle } from "lucide-react";
import { QuestionnaireResponse } from "../pages/Index";

interface Question {
  id: keyof QuestionnaireResponse;
  title: string;
  description: string;
  options: { value: string; label: string; description: string }[];
}

const questions: Question[] = [
  {
    id: 'dataVolume',
    title: 'Data Volume Characteristics',
    description: 'What is the typical volume of data being transferred per transaction/batch?',
    options: [
      { value: 'low', label: 'Low Volume', description: 'Under 1MB per transaction, < 1000 records' },
      { value: 'medium', label: 'Medium Volume', description: '1-100MB per transaction, 1K-100K records' },
      { value: 'high', label: 'High Volume', description: 'Over 100MB per transaction, > 100K records' }
    ]
  },
  {
    id: 'latencyRequirement',
    title: 'Latency Tolerance',
    description: 'What is the maximum acceptable delay for data to be available in the target system?',
    options: [
      { value: 'immediate', label: 'Immediate', description: 'Sub-second response required (< 1 second)' },
      { value: 'seconds', label: 'Near Real-Time', description: 'Acceptable delay of 1-30 seconds' },
      { value: 'minutes', label: 'Short Delay', description: 'Acceptable delay of 1-15 minutes' },
      { value: 'hours', label: 'Scheduled', description: 'Hourly, daily, or scheduled processing acceptable' }
    ]
  },
  {
    id: 'transactionCriticality',
    title: 'Transaction Criticality',
    description: 'How critical are these transactions to business operations?',
    options: [
      { value: 'mission-critical', label: 'Mission Critical', description: 'System downtime causes immediate business impact' },
      { value: 'business-critical', label: 'Business Critical', description: 'Important but short delays acceptable' },
      { value: 'non-critical', label: 'Non-Critical', description: 'Delays have minimal business impact' }
    ]
  },
  {
    id: 'consistencyNeeds',
    title: 'Data Consistency Requirements',
    description: 'What level of data consistency is required across systems?',
    options: [
      { value: 'strong', label: 'Strong Consistency', description: 'All systems must have identical data immediately' },
      { value: 'eventual', label: 'Eventual Consistency', description: 'Systems will converge to consistent state over time' },
      { value: 'weak', label: 'Weak Consistency', description: 'Some data differences between systems acceptable' }
    ]
  },
  {
    id: 'systemCoupling',
    title: 'System Coupling Preferences',
    description: 'What level of coupling between systems is acceptable?',
    options: [
      { value: 'tight', label: 'Tight Coupling', description: 'Direct system dependencies acceptable for performance' },
      { value: 'loose', label: 'Loose Coupling', description: 'Prefer decoupled systems with some interdependency' },
      { value: 'independent', label: 'Independent', description: 'Systems should operate independently' }
    ]
  },
  {
    id: 'errorHandling',
    title: 'Error Handling Strategy',
    description: 'How should integration errors be handled and communicated?',
    options: [
      { value: 'immediate', label: 'Immediate Response', description: 'Errors must be reported immediately to caller' },
      { value: 'resilient', label: 'Resilient Processing', description: 'Retry logic and dead letter handling preferred' },
      { value: 'retry-batch', label: 'Batch Retry', description: 'Errors can be processed in batch during maintenance windows' }
    ]
  },
  {
    id: 'complianceRequirements',
    title: 'Compliance and Regulatory Needs',
    description: 'What compliance requirements affect your integration approach?',
    options: [
      { value: 'strict', label: 'Strict Compliance', description: 'GDPR, HIPAA, SOX - strict audit trails required' },
      { value: 'moderate', label: 'Moderate Compliance', description: 'Some regulatory requirements but flexible implementation' },
      { value: 'minimal', label: 'Minimal Compliance', description: 'Standard business compliance only' }
    ]
  },
  {
    id: 'dataRetention',
    title: 'Data Retention and Archival',
    description: 'How long must integration data and logs be retained?',
    options: [
      { value: 'long-term', label: 'Long-term (7+ years)', description: 'Extended retention for regulatory compliance' },
      { value: 'medium-term', label: 'Medium-term (1-7 years)', description: 'Standard business retention periods' },
      { value: 'short-term', label: 'Short-term (< 1 year)', description: 'Minimal retention requirements' }
    ]
  },
  {
    id: 'scalabilityNeeds',
    title: 'Scalability Requirements',
    description: 'How must the integration scale with business growth?',
    options: [
      { value: 'elastic', label: 'Elastic Scaling', description: 'Must auto-scale with demand fluctuations' },
      { value: 'predictable', label: 'Predictable Growth', description: 'Steady, predictable scaling requirements' },
      { value: 'fixed', label: 'Fixed Capacity', description: 'Stable volume, minimal scaling needed' }
    ]
  },
  {
    id: 'securityRequirements',
    title: 'Security and Authentication',
    description: 'What security measures are required for data transmission?',
    options: [
      { value: 'enterprise', label: 'Enterprise Security', description: 'Multi-factor auth, encryption, network isolation' },
      { value: 'standard', label: 'Standard Security', description: 'TLS encryption, API keys, basic authentication' },
      { value: 'basic', label: 'Basic Security', description: 'Standard protocols, minimal additional security' }
    ]
  },
  {
    id: 'maintenanceWindow',
    title: 'Maintenance Window Availability',
    description: 'Are there available maintenance windows for integration processing?',
    options: [
      { value: 'none', label: 'No Maintenance Windows', description: '24/7 operation required' },
      { value: 'limited', label: 'Limited Windows', description: 'Short windows available (1-2 hours)' },
      { value: 'flexible', label: 'Flexible Windows', description: 'Regular maintenance windows available' }
    ]
  },
  {
    id: 'budgetConstraints',
    title: 'Budget and Resource Constraints',
    description: 'What are your budget constraints for integration infrastructure?',
    options: [
      { value: 'high', label: 'High Budget', description: 'Premium solutions and infrastructure acceptable' },
      { value: 'medium', label: 'Medium Budget', description: 'Balanced cost-performance requirements' },
      { value: 'low', label: 'Low Budget', description: 'Cost optimization is primary concern' }
    ]
  },
  {
    id: 'teamExpertise',
    title: 'Team Technical Expertise',
    description: 'What is your team\'s experience with integration technologies?',
    options: [
      { value: 'expert', label: 'Expert Level', description: 'Experienced with complex integration patterns' },
      { value: 'intermediate', label: 'Intermediate', description: 'Some integration experience, learning capacity' },
      { value: 'basic', label: 'Basic Level', description: 'Limited integration experience, prefer simple solutions' }
    ]
  },
  {
    id: 'legacyIntegration',
    title: 'Legacy System Constraints',
    description: 'How do legacy systems impact your integration approach?',
    options: [
      { value: 'modern', label: 'Modern Systems', description: 'All systems support modern integration patterns' },
      { value: 'mixed', label: 'Mixed Environment', description: 'Combination of modern and legacy systems' },
      { value: 'legacy-heavy', label: 'Legacy Heavy', description: 'Many legacy systems with limited integration options' }
    ]
  },
  {
    id: 'performanceMonitoring',
    title: 'Performance Monitoring Needs',
    description: 'What level of performance monitoring and observability is required?',
    options: [
      { value: 'comprehensive', label: 'Comprehensive', description: 'Full observability, metrics, tracing, and alerting' },
      { value: 'standard', label: 'Standard', description: 'Basic monitoring and error alerting' },
      { value: 'minimal', label: 'Minimal', description: 'Simple logging and basic health checks' }
    ]
  },
  {
    id: 'businessContinuity',
    title: 'Business Continuity Requirements',
    description: 'What are your disaster recovery and business continuity needs?',
    options: [
      { value: 'high-availability', label: 'High Availability', description: 'Multi-region, automatic failover required' },
      { value: 'standard-recovery', label: 'Standard Recovery', description: 'Backup systems, acceptable brief downtime' },
      { value: 'basic-backup', label: 'Basic Backup', description: 'Standard backup procedures sufficient' }
    ]
  }
];

interface IntegrationQuestionnaireProps {
  onComplete: (responses: QuestionnaireResponse) => void;
}

export const IntegrationQuestionnaire = ({ onComplete }: IntegrationQuestionnaireProps) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<Partial<QuestionnaireResponse>>({});

  const handleAnswer = (value: string) => {
    const question = questions[currentQuestion];
    setResponses(prev => ({
      ...prev,
      [question.id]: value
    }));
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      onComplete(responses as QuestionnaireResponse);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const question = questions[currentQuestion];
  const currentResponse = responses[question.id];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-900">
              Enterprise Integration Assessment
            </h1>
            <span className="text-sm text-gray-600">
              Question {currentQuestion + 1} of {questions.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl">{question.title}</CardTitle>
            <CardDescription className="text-base">
              {question.description}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {question.options.map((option) => (
              <div
                key={option.value}
                className={`border rounded-lg p-4 cursor-pointer transition-all hover:border-blue-300 hover:bg-blue-50 ${
                  currentResponse === option.value
                    ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500'
                    : 'border-gray-200'
                }`}
                onClick={() => handleAnswer(option.value)}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center mt-0.5 ${
                    currentResponse === option.value
                      ? 'border-blue-500 bg-blue-500'
                      : 'border-gray-300'
                  }`}>
                    {currentResponse === option.value && (
                      <CheckCircle className="w-3 h-3 text-white fill-current" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">
                      {option.label}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {option.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Previous
          </Button>
          
          <Button
            onClick={handleNext}
            disabled={!currentResponse}
            className="flex items-center gap-2"
          >
            {currentQuestion === questions.length - 1 ? 'Get Recommendations' : 'Next'}
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

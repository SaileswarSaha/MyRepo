
import React from 'react';
import DecisionTreeApp from '../components/DecisionTreeApp';

const Index = () => {
  return <DecisionTreeApp />;
};

export default Index;

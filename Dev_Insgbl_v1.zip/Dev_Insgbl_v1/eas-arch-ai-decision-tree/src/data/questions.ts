
import { Question } from '../types/questionnaire';

export const questions: Question[] = [
  {
    id: 'q1',
    question: 'What is your primary use case for AI integration?',
    type: 'single',
    category: 'business',
    options: [
      'Enhance productivity in Microsoft Office applications',
      'Build custom chatbots and conversational AI',
      'Develop custom AI models and applications',
      'Process and analyze large datasets',
      'Automate business processes'
    ]
  },
  {
    id: 'q2',
    question: 'What is the size of your organization?',
    type: 'single',
    category: 'business',
    options: [
      'Small business (1-50 employees)',
      'Medium business (51-500 employees)',
      'Large enterprise (500+ employees)',
      'Individual/Personal use',
      'Startup/Scale-up'
    ]
  },
  {
    id: 'q3',
    question: 'What is your technical expertise level?',
    type: 'single',
    category: 'technical',
    options: [
      'Non-technical user',
      'Basic technical knowledge',
      'Intermediate (some coding experience)',
      'Advanced (experienced developer)',
      'Expert (AI/ML specialist)'
    ]
  },
  {
    id: 'q4',
    question: 'Which Microsoft applications do you primarily use? (Select all that apply)',
    type: 'multiple',
    category: 'usage',
    options: [
      'Word, Excel, PowerPoint',
      'Outlook and Teams',
      'SharePoint and OneDrive',
      'Power Platform (Power BI, Power Apps)',
      'Azure services',
      'Dynamics 365',
      'Visual Studio/VS Code'
    ]
  },
  {
    id: 'q5',
    question: 'Do you need to integrate with external systems or APIs?',
    type: 'single',
    category: 'integration',
    options: [
      'No, only Microsoft ecosystem',
      'Yes, a few external systems',
      'Yes, many external systems',
      'Yes, complex enterprise integrations',
      'Not sure'
    ]
  },
  {
    id: 'q6',
    question: 'What type of AI capabilities do you need? (Select all that apply)',
    type: 'multiple',
    category: 'technical',
    options: [
      'Natural language processing and chat',
      'Document analysis and summarization',
      'Data analysis and insights',
      'Image and video processing',
      'Custom machine learning models',
      'Workflow automation',
      'Real-time decision making'
    ]
  },
  {
    id: 'q7',
    question: 'How important is customization for your AI solution?',
    type: 'scale',
    category: 'business',
    options: ['1', '2', '3', '4', '5'] // 1 = Not important, 5 = Very important
  },
  {
    id: 'q8',
    question: 'What is your budget range for AI implementation?',
    type: 'single',
    category: 'business',
    options: [
      'Minimal (use existing licenses)',
      'Low ($100-$1,000/month)',
      'Medium ($1,000-$10,000/month)',
      'High ($10,000+/month)',
      'Enterprise (custom pricing)'
    ]
  },
  {
    id: 'q9',
    question: 'How quickly do you need to implement the AI solution?',
    type: 'single',
    category: 'business',
    options: [
      'Immediately (within days)',
      'Short term (within weeks)',
      'Medium term (within months)',
      'Long term (6+ months)',
      'No specific timeline'
    ]
  },
  {
    id: 'q10',
    question: 'What level of data privacy and compliance do you require?',
    type: 'single',
    category: 'business',
    options: [
      'Standard business requirements',
      'Enhanced security needed',
      'Industry-specific compliance (HIPAA, GDPR, etc.)',
      'Government/Military grade',
      'Custom compliance requirements'
    ]
  },
  {
    id: 'q11',
    question: 'Do you need AI solutions that work offline or in air-gapped environments?',
    type: 'single',
    category: 'technical',
    options: [
      'No, cloud-based is fine',
      'Prefer cloud but can work online-only',
      'Need some offline capabilities',
      'Require full offline functionality',
      'Need air-gapped deployment'
    ]
  },
  {
    id: 'q12',
    question: 'What is your primary goal for implementing AI? (Select all that apply)',
    type: 'multiple',
    category: 'business',
    options: [
      'Increase employee productivity',
      'Improve customer service',
      'Reduce operational costs',
      'Gain competitive advantage',
      'Automate repetitive tasks',
      'Generate new insights from data',
      'Innovation and experimentation'
    ]
  }
];


import { AIsolution } from '../types/questionnaire';

export const aiSolutions: AISolution[] = [
  {
    id: 'M365',
    name: 'Microsoft 365 Copilot',
    description: 'AI-powered productivity assistant integrated directly into Microsoft 365 applications',
    bestFor: [
      'Knowledge workers using Office apps',
      'Teams collaboration enhancement',
      'Document creation and analysis',
      'Meeting productivity'
    ],
    features: [
      'Word, Excel, PowerPoint integration',
      'Teams meeting summaries',
      'Outlook email assistance',
      'SharePoint content discovery',
      'Natural language queries'
    ],
    requirements: [
      'Microsoft 365 E3/E5 license',
      'Copilot for Microsoft 365 license',
      'Azure Active Directory',
      'Minimum user count requirements'
    ],
    icon: '📝'
  },
  {
    id: 'CopilotStudio',
    name: 'Microsoft Copilot Studio',
    description: 'Low-code platform for building custom copilots and conversational AI experiences',
    bestFor: [
      'Custom chatbot development',
      'Business process automation',
      'Customer service solutions',
      'Internal help desk systems'
    ],
    features: [
      'Visual bot designer',
      'Power Platform integration',
      'Multi-channel deployment',
      'Analytics and insights',
      'Pre-built templates'
    ],
    requirements: [
      'Power Platform license',
      'Basic technical knowledge',
      'Integration planning',
      'Content management'
    ],
    icon: '🤖'
  },
  {
    id: 'AIFoundry',
    name: 'Azure AI Foundry',
    description: 'Comprehensive platform for building, deploying, and managing custom AI models and applications',
    bestFor: [
      'Custom AI model development',
      'Large-scale AI applications',
      'Advanced analytics',
      'Research and experimentation'
    ],
    features: [
      'Custom model training',
      'MLOps capabilities',
      'Advanced AI services',
      'Scalable infrastructure',
      'Enterprise security'
    ],
    requirements: [
      'Azure subscription',
      'Technical expertise',
      'Development resources',
      'Significant investment'
    ],
    icon: '⚡'
  }
];

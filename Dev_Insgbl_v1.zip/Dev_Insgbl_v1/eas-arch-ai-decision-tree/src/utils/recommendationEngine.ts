
import { Answer } from '../types/questionnaire';

interface RecommendationResult {
  recommendation: 'M365' | 'CopilotStudio' | 'AIFoundry' | 'Multiple';
  confidence: number;
  reasoning: string[];
}

export const calculateRecommendation = (answers: Answer[]): RecommendationResult => {
  const scores = {
    M365: 0,
    CopilotStudio: 0,
    AIFoundry: 0
  };

  const reasoning: string[] = [];

  answers.forEach(answer => {
    const value = answer.value;
    
    switch (answer.questionId) {
      case 'q1': // Primary use case
        if (typeof value === 'string') {
          if (value.includes('Microsoft Office applications')) {
            scores.M365 += 30;
            reasoning.push('Your focus on Microsoft Office productivity aligns with M365 Copilot');
          } else if (value.includes('custom chatbots')) {
            scores.CopilotStudio += 30;
            reasoning.push('Building custom chatbots is the core strength of Copilot Studio');
          } else if (value.includes('custom AI models')) {
            scores.AIFoundry += 30;
            reasoning.push('Custom AI model development requires Azure AI Foundry capabilities');
          } else if (value.includes('large datasets')) {
            scores.AIFoundry += 25;
            scores.M365 += 10;
            reasoning.push('Large dataset processing favors Azure AI Foundry or enhanced M365 features');
          }
        }
        break;

      case 'q2': // Organization size
        if (typeof value === 'string') {
          if (value.includes('Large enterprise')) {
            scores.M365 += 20;
            scores.AIFoundry += 15;
            reasoning.push('Enterprise scale often benefits from M365 Copilot or Azure AI Foundry');
          } else if (value.includes('Small business') || value.includes('Medium business')) {
            scores.CopilotStudio += 15;
            scores.M365 += 10;
          } else if (value.includes('Individual')) {
            scores.M365 += 25;
          }
        }
        break;

      case 'q3': // Technical expertise
        if (typeof value === 'string') {
          if (value.includes('Non-technical') || value.includes('Basic technical')) {
            scores.M365 += 25;
            reasoning.push('Your technical level suits M365 Copilot\'s user-friendly approach');
          } else if (value.includes('Intermediate')) {
            scores.CopilotStudio += 20;
            scores.M365 += 15;
            reasoning.push('Intermediate skills are perfect for Copilot Studio\'s low-code platform');
          } else if (value.includes('Advanced') || value.includes('Expert')) {
            scores.AIFoundry += 25;
            scores.CopilotStudio += 10;
            reasoning.push('Your advanced technical skills can leverage Azure AI Foundry\'s full potential');
          }
        }
        break;

      case 'q4': // Microsoft applications used
        if (Array.isArray(value)) {
          if (value.some(app => app.includes('Word, Excel, PowerPoint'))) {
            scores.M365 += 25;
            reasoning.push('Heavy Office application usage strongly indicates M365 Copilot');
          }
          if (value.some(app => app.includes('Power Platform'))) {
            scores.CopilotStudio += 20;
            reasoning.push('Power Platform experience aligns well with Copilot Studio');
          }
          if (value.some(app => app.includes('Azure services'))) {
            scores.AIFoundry += 20;
            reasoning.push('Azure experience supports Azure AI Foundry adoption');
          }
          if (value.some(app => app.includes('Teams'))) {
            scores.M365 += 15;
            scores.CopilotStudio += 10;
          }
        }
        break;

      case 'q5': // External integrations
        if (typeof value === 'string') {
          if (value.includes('No, only Microsoft ecosystem')) {
            scores.M365 += 20;
            reasoning.push('Microsoft-only environment is ideal for M365 Copilot');
          } else if (value.includes('few external systems')) {
            scores.CopilotStudio += 15;
            scores.M365 += 10;
          } else if (value.includes('many external') || value.includes('complex enterprise')) {
            scores.AIFoundry += 25;
            scores.CopilotStudio += 15;
            reasoning.push('Complex integrations require Azure AI Foundry\'s flexibility');
          }
        }
        break;

      case 'q6': // AI capabilities needed
        if (Array.isArray(value)) {
          if (value.some(cap => cap.includes('Document analysis'))) {
            scores.M365 += 20;
            reasoning.push('Document analysis is a key M365 Copilot strength');
          }
          if (value.some(cap => cap.includes('Natural language processing'))) {
            scores.CopilotStudio += 20;
            scores.M365 += 15;
          }
          if (value.some(cap => cap.includes('Custom machine learning'))) {
            scores.AIFoundry += 25;
            reasoning.push('Custom ML models require Azure AI Foundry');
          }
          if (value.some(cap => cap.includes('Workflow automation'))) {
            scores.CopilotStudio += 15;
            reasoning.push('Workflow automation is well-suited for Copilot Studio');
          }
        }
        break;

      case 'q7': // Customization importance (scale 1-5)
        if (typeof value === 'number') {
          if (value >= 4) {
            scores.AIFoundry += 20;
            scores.CopilotStudio += 15;
            reasoning.push('High customization needs favor Azure AI Foundry or Copilot Studio');
          } else if (value <= 2) {
            scores.M365 += 20;
            reasoning.push('Low customization needs align with M365 Copilot\'s ready-to-use features');
          }
        }
        break;

      case 'q8': // Budget
        if (typeof value === 'string') {
          if (value.includes('Minimal')) {
            scores.M365 += 25;
            reasoning.push('Minimal budget works well with existing M365 licenses');
          } else if (value.includes('Low') || value.includes('Medium')) {
            scores.CopilotStudio += 20;
            scores.M365 += 15;
          } else if (value.includes('High') || value.includes('Enterprise')) {
            scores.AIFoundry += 20;
            reasoning.push('Higher budget enables Azure AI Foundry\'s advanced capabilities');
          }
        }
        break;

      case 'q9': // Implementation timeline
        if (typeof value === 'string') {
          if (value.includes('Immediately') || value.includes('Short term')) {
            scores.M365 += 20;
            scores.CopilotStudio += 15;
            reasoning.push('Quick implementation timeline favors M365 Copilot or Copilot Studio');
          } else if (value.includes('Long term')) {
            scores.AIFoundry += 15;
            reasoning.push('Longer timeline allows for Azure AI Foundry\'s comprehensive development');
          }
        }
        break;

      case 'q10': // Data privacy and compliance
        if (typeof value === 'string') {
          if (value.includes('Standard business')) {
            scores.M365 += 15;
            scores.CopilotStudio += 15;
          } else if (value.includes('Enhanced security') || value.includes('Industry-specific')) {
            scores.AIFoundry += 20;
            scores.M365 += 10;
            reasoning.push('Enhanced security requirements support Azure AI Foundry or enterprise M365');
          } else if (value.includes('Government') || value.includes('Custom compliance')) {
            scores.AIFoundry += 25;
            reasoning.push('Government-grade security requires Azure AI Foundry\'s advanced controls');
          }
        }
        break;

      case 'q11': // Offline capabilities
        if (typeof value === 'string') {
          if (value.includes('cloud-based is fine')) {
            scores.M365 += 15;
            scores.CopilotStudio += 15;
          } else if (value.includes('offline') || value.includes('air-gapped')) {
            scores.AIFoundry += 25;
            reasoning.push('Offline/air-gapped requirements need Azure AI Foundry\'s deployment flexibility');
          }
        }
        break;

      case 'q12': // Primary goals
        if (Array.isArray(value)) {
          if (value.some(goal => goal.includes('employee productivity'))) {
            scores.M365 += 20;
            reasoning.push('Employee productivity is M365 Copilot\'s primary value proposition');
          }
          if (value.some(goal => goal.includes('customer service'))) {
            scores.CopilotStudio += 20;
            reasoning.push('Customer service improvements align with Copilot Studio capabilities');
          }
          if (value.some(goal => goal.includes('competitive advantage') || goal.includes('Innovation'))) {
            scores.AIFoundry += 15;
            reasoning.push('Innovation and competitive advantage often require Azure AI Foundry\'s advanced features');
          }
        }
        break;
    }
  });

  // Determine the recommendation
  const maxScore = Math.max(scores.M365, scores.CopilotStudio, scores.AIFoundry);
  const totalScore = scores.M365 + scores.CopilotStudio + scores.AIFoundry;
  
  let recommendation: 'M365' | 'CopilotStudio' | 'AIFoundry' | 'Multiple';
  let confidence: number;

  if (maxScore === 0) {
    recommendation = 'M365'; // Default fallback
    confidence = 50;
    reasoning.push('Based on general business needs, M365 Copilot provides a good starting point');
  } else {
    confidence = Math.round((maxScore / totalScore) * 100);
    
    if (scores.M365 === maxScore) {
      recommendation = 'M365';
    } else if (scores.CopilotStudio === maxScore) {
      recommendation = 'CopilotStudio';
    } else {
      recommendation = 'AIFoundry';
    }

    // Check for close scores (multiple solutions viable)
    const scoreRange = maxScore - Math.min(scores.M365, scores.CopilotStudio, scores.AIFoundry);
    if (scoreRange < 20 && totalScore > 50) {
      recommendation = 'Multiple';
      confidence = 75;
      reasoning.push('Multiple solutions could work well for your needs - consider a phased approach');
    }
  }

  return {
    recommendation,
    confidence: Math.min(95, Math.max(50, confidence)), // Cap confidence between 50-95%
    reasoning: reasoning.slice(0, 5) // Limit to top 5 reasons
  };
};

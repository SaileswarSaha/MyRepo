
import React, { useState } from 'react';
import WelcomeScreen from './WelcomeScreen';
import QuestionnaireFlow from './QuestionnaireFlow';
import RecommendationResult from './RecommendationResult';
import { QuestionnaireData } from '../types/questionnaire';

type AppState = 'welcome' | 'questionnaire' | 'result';

const DecisionTreeApp = () => {
  const [currentState, setCurrentState] = useState<AppState>('welcome');
  const [questionnaireData, setQuestionnaireData] = useState<QuestionnaireData | null>(null);

  const handleStartQuestionnaire = () => {
    setCurrentState('questionnaire');
  };

  const handleQuestionnaireComplete = (data: QuestionnaireData) => {
    setQuestionnaireData(data);
    setCurrentState('result');
  };

  const handleRestart = () => {
    setQuestionnaireData(null);
    setCurrentState('welcome');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {currentState === 'welcome' && (
        <WelcomeScreen onStart={handleStartQuestionnaire} />
      )}
      {currentState === 'questionnaire' && (
        <QuestionnaireFlow onComplete={handleQuestionnaireComplete} />
      )}
      {currentState === 'result' && questionnaireData && (
        <RecommendationResult 
          data={questionnaireData} 
          onRestart={handleRestart} 
        />
      )}
    </div>
  );
};

export default DecisionTreeApp;


import React from 'react';
import { Question, Answer } from '../types/questionnaire';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';

interface QuestionCardProps {
  question: Question;
  answer?: Answer;
  onAnswer: (answer: Answer) => void;
}

const QuestionCard = ({ question, answer, onAnswer }: QuestionCardProps) => {
  const handleSingleAnswer = (value: string) => {
    onAnswer({
      questionId: question.id,
      value
    });
  };

  const handleMultipleAnswer = (option: string, checked: boolean) => {
    const currentValues = (answer?.value as string[]) || [];
    let newValues: string[];
    
    if (checked) {
      newValues = [...currentValues, option];
    } else {
      newValues = currentValues.filter(v => v !== option);
    }
    
    onAnswer({
      questionId: question.id,
      value: newValues
    });
  };

  const handleScaleAnswer = (value: number[]) => {
    onAnswer({
      questionId: question.id,
      value: value[0]
    });
  };

  return (
    <div>
      <h3 className="text-xl font-semibold text-gray-900 mb-6">
        {question.question}
      </h3>

      {question.type === 'single' && (
        <RadioGroup
          value={answer?.value as string || ''}
          onValueChange={handleSingleAnswer}
          className="space-y-3"
        >
          {question.options.map((option, index) => (
            <div key={index} className="flex items-center space-x-3">
              <RadioGroupItem value={option} id={`${question.id}-${index}`} />
              <Label 
                htmlFor={`${question.id}-${index}`}
                className="text-sm font-medium leading-relaxed cursor-pointer"
              >
                {option}
              </Label>
            </div>
          ))}
        </RadioGroup>
      )}

      {question.type === 'multiple' && (
        <div className="space-y-3">
          {question.options.map((option, index) => (
            <div key={index} className="flex items-center space-x-3">
              <Checkbox
                id={`${question.id}-${index}`}
                checked={(answer?.value as string[] || []).includes(option)}
                onCheckedChange={(checked) => handleMultipleAnswer(option, checked as boolean)}
              />
              <Label 
                htmlFor={`${question.id}-${index}`}
                className="text-sm font-medium leading-relaxed cursor-pointer"
              >
                {option}
              </Label>
            </div>
          ))}
        </div>
      )}

      {question.type === 'scale' && (
        <div className="space-y-4">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Not Important</span>
            <span>Very Important</span>
          </div>
          <Slider
            value={[answer?.value as number || 3]}
            onValueChange={handleScaleAnswer}
            max={5}
            min={1}
            step={1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-500">
            <span>1</span>
            <span>2</span>
            <span>3</span>
            <span>4</span>
            <span>5</span>
          </div>
          {answer && (
            <p className="text-center text-sm font-medium text-blue-600">
              Selected: {answer.value}
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default QuestionCard;

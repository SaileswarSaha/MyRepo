
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { questions } from '../data/questions';
import { Answer, QuestionnaireData } from '../types/questionnaire';
import QuestionCard from './QuestionCard';
import { calculateRecommendation } from '../utils/recommendationEngine';

interface QuestionnaireFlowProps {
  onComplete: (data: QuestionnaireData) => void;
}

const QuestionnaireFlow = ({ onComplete }: QuestionnaireFlowProps) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  const handleAnswer = (answer: Answer) => {
    const updatedAnswers = answers.filter(a => a.questionId !== answer.questionId);
    updatedAnswers.push(answer);
    setAnswers(updatedAnswers);
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Calculate recommendation and complete
      const recommendation = calculateRecommendation(answers);
      onComplete({
        answers,
        ...recommendation
      });
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const currentAnswer = answers.find(a => a.questionId === currentQuestion.id);
  const canProceed = currentAnswer !== undefined;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-gray-900">
            Question {currentQuestionIndex + 1} of {questions.length}
          </h2>
          <span className="text-sm text-gray-600">
            {Math.round(progress)}% Complete
          </span>
        </div>
        <Progress value={progress} className="w-full" />
      </div>

      <Card className="p-8 mb-8">
        <QuestionCard
          question={currentQuestion}
          answer={currentAnswer}
          onAnswer={handleAnswer}
        />
      </Card>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={handlePrevious}
          disabled={currentQuestionIndex === 0}
          className="flex items-center"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <Button
          onClick={handleNext}
          disabled={!canProceed}
          className="flex items-center bg-blue-600 hover:bg-blue-700"
        >
          {currentQuestionIndex === questions.length - 1 ? 'Get Recommendation' : 'Next'}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default QuestionnaireFlow;

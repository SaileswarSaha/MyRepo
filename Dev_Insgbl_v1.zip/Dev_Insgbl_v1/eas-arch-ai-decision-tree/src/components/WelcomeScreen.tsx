
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowRight, Brain, MessageSquare, Zap } from 'lucide-react';

interface WelcomeScreenProps {
  onStart: () => void;
}

const WelcomeScreen = ({ onStart }: WelcomeScreenProps) => {
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="text-center mb-12">
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-blue-600 rounded-full">
            <Brain className="w-12 h-12 text-white" />
          </div>
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Microsoft AI Solutions Decision Tree
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Discover which Microsoft AI solution best fits your needs through our comprehensive questionnaire.
          Get personalized recommendations for M365 Copilot, Copilot Studio, or Azure AI Foundry.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <Card className="p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center mb-4">
            <div className="p-2 bg-blue-100 rounded-lg mr-3">
              <MessageSquare className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold">M365 Copilot</h3>
          </div>
          <p className="text-gray-600 text-sm">
            AI-powered productivity assistant integrated into Microsoft 365 applications
          </p>
        </Card>

        <Card className="p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center mb-4">
            <div className="p-2 bg-green-100 rounded-lg mr-3">
              <MessageSquare className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold">Copilot Studio</h3>
          </div>
          <p className="text-gray-600 text-sm">
            Low-code platform for building custom copilots and conversational AI
          </p>
        </Card>

        <Card className="p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-center mb-4">
            <div className="p-2 bg-purple-100 rounded-lg mr-3">
              <Zap className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold">Azure AI Foundry</h3>
          </div>
          <p className="text-gray-600 text-sm">
            Comprehensive platform for building and deploying custom AI models
          </p>
        </Card>
      </div>

      <div className="text-center">
        <Button 
          onClick={onStart} 
          size="lg" 
          className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
        >
          Start Decision Tree
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
        <p className="text-sm text-gray-500 mt-4">
          Takes approximately 3-5 minutes • 12 questions
        </p>
      </div>
    </div>
  );
};

export default WelcomeScreen;

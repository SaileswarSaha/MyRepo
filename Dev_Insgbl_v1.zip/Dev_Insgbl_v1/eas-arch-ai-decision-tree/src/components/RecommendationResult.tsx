
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { QuestionnaireData } from '../types/questionnaire';
import { aiSolutions } from '../data/aiSolutions';
import { RotateCcw, CheckCircle, AlertCircle, Info } from 'lucide-react';

interface RecommendationResultProps {
  data: QuestionnaireData;
  onRestart: () => void;
}

const RecommendationResult = ({ data, onRestart }: RecommendationResultProps) => {
  const primarySolution = aiSolutions.find(s => s.id === data.recommendation);
  
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-green-600 bg-green-100';
    if (confidence >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getConfidenceIcon = (confidence: number) => {
    if (confidence >= 80) return <CheckCircle className="w-4 h-4" />;
    if (confidence >= 60) return <AlertCircle className="w-4 h-4" />;
    return <Info className="w-4 h-4" />;
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Your AI Solution Recommendation
        </h1>
        <div className="flex items-center justify-center gap-2">
          <Badge className={`px-3 py-1 ${getConfidenceColor(data.confidence)}`}>
            {getConfidenceIcon(data.confidence)}
            {data.confidence}% Confidence
          </Badge>
        </div>
      </div>

      {primarySolution && (
        <Card className="p-8 mb-8 border-2 border-blue-200 bg-blue-50">
          <div className="text-center mb-6">
            <div className="text-4xl mb-4">{primarySolution.icon}</div>
            <h2 className="text-2xl font-bold text-blue-900 mb-2">
              {primarySolution.name}
            </h2>
            <p className="text-blue-700 text-lg">
              {primarySolution.description}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Best For:</h3>
              <ul className="space-y-2">
                {primarySolution.bestFor.map((item, index) => (
                  <li key={index} className="text-sm text-gray-700 flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Key Features:</h3>
              <ul className="space-y-2">
                {primarySolution.features.map((feature, index) => (
                  <li key={index} className="text-sm text-gray-700 flex items-start">
                    <CheckCircle className="w-4 h-4 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Requirements:</h3>
              <ul className="space-y-2">
                {primarySolution.requirements.map((req, index) => (
                  <li key={index} className="text-sm text-gray-700 flex items-start">
                    <AlertCircle className="w-4 h-4 text-orange-500 mr-2 mt-0.5 flex-shrink-0" />
                    {req}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Card>
      )}

      <Card className="p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Why This Recommendation?
        </h3>
        <div className="space-y-2">
          {data.reasoning.map((reason, index) => (
            <p key={index} className="text-gray-700 flex items-start">
              <Info className="w-4 h-4 text-blue-500 mr-2 mt-1 flex-shrink-0" />
              {reason}
            </p>
          ))}
        </div>
      </Card>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {aiSolutions.filter(s => s.id !== data.recommendation).map((solution) => (
          <Card key={solution.id} className="p-6 opacity-75 hover:opacity-100 transition-opacity">
            <div className="text-center mb-4">
              <div className="text-2xl mb-2">{solution.icon}</div>
              <h3 className="font-semibold text-gray-800">{solution.name}</h3>
            </div>
            <p className="text-sm text-gray-600 text-center">
              {solution.description}
            </p>
          </Card>
        ))}
      </div>

      <div className="text-center">
        <Button onClick={onRestart} variant="outline" className="flex items-center mx-auto">
          <RotateCcw className="w-4 h-4 mr-2" />
          Take Assessment Again
        </Button>
      </div>
    </div>
  );
};

export default RecommendationResult;

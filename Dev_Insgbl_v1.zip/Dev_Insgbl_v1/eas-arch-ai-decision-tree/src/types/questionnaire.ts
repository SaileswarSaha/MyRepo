
export interface Question {
  id: string;
  question: string;
  type: 'single' | 'multiple' | 'scale';
  options: string[];
  category: 'business' | 'technical' | 'usage' | 'integration';
}

export interface Answer {
  questionId: string;
  value: string | string[] | number;
}

export interface QuestionnaireData {
  answers: Answer[];
  recommendation: 'M365' | 'CopilotStudio' | 'AIFoundry' | 'Multiple';
  confidence: number;
  reasoning: string[];
}

export interface AISolution {
  id: 'M365' | 'CopilotStudio' | 'AIFoundry';
  name: string;
  description: string;
  bestFor: string[];
  features: string[];
  requirements: string[];
  icon: string;
}

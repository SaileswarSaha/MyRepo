# Azure Data Factory (ADF) Deployment

This repository provides a reusable solution to deploy an Azure Data Factory (ADF) instance using a Bicep module (`main.bicep`), wrapped by a template pipeline (`data-factory.yaml`), and orchestrated via a calling Infrastructure-as-Code (IaC) pipeline (`adf-data-ingestion-v1-iac.yaml`). This setup supports consistent, environment-specific deployments across multiple stages such as sandbox, development, test, and production.

## Table of Contents

- [Overview](#overview)
- [What Can Be Deployed](#what-can-be-deployed)
- [Reusability](#reusability)
- [Module: main.bicep](#module-mainbicep)
  - [Parameters](#parameters)
  - [Outputs](#outputs)
- [Wrapper Pipeline: data-factory.yaml](#Wrapper-pipeline:-data-factory.yaml)
  - [Role as Wrapper](#role-as-wrapper)
- [Procedure to Create a New Calling Pipeline](#procedure-to-create-a-new-calling-pipeline)
- [Variable File: sbox.yaml](#variable-file:-sbox.yaml)
- [Implementation Guide](#implementation-guide)
- [Troubleshooting](#troubleshooting)
- [Notes](#notes)
- [Resources](#resources)

## Overview

The `main.bicep` module defines the core infrastructure for Azure Data Factory, including integration runtimes, Git configurations, managed identities, and private endpoints. The `data-factory.yaml` file is a pipeline template that acts as a wrapper, simplifying the deployment logic. The `adf-data-ingestion-v1-iac.yaml` is a calling pipeline that orchestrates the entire process using values from the environment-specific variable file (`sbox.yaml`).

## What Can Be Deployed

- Azure Data Factory instance with:
  - System- or user-assigned managed identities
  - Git integration (FactoryVSTSConfiguration)
  - Managed Virtual Network & Integration Runtimes
  - Managed Private Endpoints for storage and key vault
  - Global parameters, diagnostic settings, and role assignments

## Reusability

- **Fixed Wrapper**: `data-factory.yaml` is reusable and parameter-driven.
- **Customizable IaC**: Modify `adf-data-ingestion-v1-iac.yaml` and `sbox.yaml` for each environment.
- **Multi-Environment Support**: Use a different variable file (`sbox.yaml`, `dev.yaml`, `uat.yaml`, `prod.yaml`, `stage.yaml`, etc.) for each stage.

## Prerequisites

- Azure Subscription with Contributor permissions
- Azure DevOps project and service connection
- Azure CLI, Bicep CLI, and PowerShell Core installed on agent
- Existing resource group and networking setup
- Access to private DNS zones and Log Analytics (if diagnostics are enabled)

## Module: main.bicep

The Bicep module is stored in the core IaC library at `eas-azure-iac-core-library/bicep/res/data-factory/main.bicep`.

### Parameters

| Parameter                       | Type    | Required | Default           | Description |
|----------------------------------|---------|----------|-------------------|-------------|
| `dataFactoryName`              | string  | Yes      | -                 | Name of the Azure Data Factory instance. |
| `location`                     | string  | Yes      | Resource Group    | Deployment region. |
| `managedVirtualNetworkName`   | string  | No       | -                 | Name of the Managed VNet within ADF. |
| `integrationRuntimes`         | array   | No       | `[]`              | Array of integration runtimes. |
| `credentials`                 | array   | No       | `[]`              | List of credentials to configure. |
| `globalParameters`            | object  | No       | `{}`              | Global parameters for pipelines or datasets. |
| `managedIdentities`           | object  | No       | `{}`              | Managed identity configuration (system or user-assigned). |
| `gitConfiguration`            | object  | No       | `{}`              | Azure DevOps Git configuration. |
| `privateEndpoints`            | array   | No       | `[]`              | Configuration for managed private endpoints. |
| `diagnosticSettings`         | array   | No       | `[]`              | Diagnostic settings for monitoring. |
| `tags`                        | object  | No       | `{}`              | Resource tags. |

### Outputs

| Output              | Type    | Description |
|---------------------|---------|-------------|
| `name`              | string  | Name of the deployed Data Factory. |
| `resourceId`        | string  | Resource ID of the ADF instance. |
| `resourceGroupName` | string  | The resource group name. |
| `location`          | string  | The location of the ADF. |

## Wrapper Pipeline: data-factory.yaml

### Role as Wrapper

The `data-factory.yaml` pipeline serves as a wrapper for the ADF deployment. It:

- Accepts environment-specific parameters from the calling pipeline and variable file
- Validates and deploys the ADF Bicep template using `az deployment group validate` and `az deployment group create`
- Configures supporting components such as managed identities, private endpoints, and diagnostics

> You **do not** need to modify `data-factory.yaml`. It is designed for reuse across environments.

The calling pipeline coordinates the entire deployment process. It performs the following:

- Installs prerequisites (CLI tools, extensions)
- Deploys managed identities and prerequisites (Key Vault, Application Insights, etc.)
- Resolves dynamic values (e.g., UAMI resource ID, workspace ID)
- Calls the ADF wrapper (`data-factory.yaml`) to deploy the Bicep module

> **Pipeline path**: `infra/data-factory/v1/adf-data-ingestion-v1-iac.yaml`

## Procedure to Create a New Calling Pipeline

Follow these steps to create a new calling pipeline for deploying Azure Data Factory:

### Folder Structure

```
eas-azure-iac-core-pipeline/
├── infra/
│ ├── data-factory/
│ │ ├── v1/
│ │ │ └── adf-data-ingestion-v1-iac.yaml # Calling pipeline file
│ │ ├── variables/
│ │ │ ├── sbox.yaml # Sandbox environment
│ │ │ ├── dev.yaml # Development
│ │ │ ├── test.yaml # Test
│ │ │ └── uat.yaml # UAT
```

### Steps to Create a New Calling Pipeline

1. **Create the Pipeline File**
   - Copy `adf-data-ingestion-v1-iac.yaml` into `infra/data-factory/v1/`
   - Update the `pipeline_branch` default to match the core library branch
   - Ensure it references `data-factory.yaml` from the correct repository path

2. **Create Variable Files**
   - Copy `sbox.yaml` and modify for each environment (dev, test, uat)
   - Set unique values like `dataFactoryName`, `resourceGroupName`, `gitConfigureLater`, etc.
   - Ensure correct subscription and resource group references

3. **Configure Azure DevOps Pipeline**
   - Go to Azure DevOps > Pipelines > New Pipeline
   - Use **"Existing Azure Pipelines YAML file"** and point to `infra/data-factory/v1/adf-data-ingestion-v1-iac.yaml`
   - Link the proper service connection (`AZURE_SUBSCRIPTION`)

4. **Test the Pipeline**
   - Run the pipeline manually with `deployAction: deploy`
   - Monitor all stages: prerequisites, identity, wrapper, and validation
   - Verify ADF and related resources in the Azure Portal

5. **Version Control and CI/CD**
   - Use Git branches (e.g., `feature/adf-deploy`) during development
   - Merge to `main` after successful testing
   - Optional: integrate pull request validations and scheduled runs

## Variable File: sbox.yaml

The `sbox.yaml` defines all environment-specific values. Example entries:

```yaml
- name: dataFactoryName
  value: adf-int-sbox-eastus-001

- name: gitConfigureLater
  value: true

- name: managedIdentityName 
  value: id-adf-sandbox-eastus-001

- name: integrationRuntimeName
  value: AutoResolveIntegrationRuntime

- name: credentialsName
  value: cred-uami

```

Note: Place all variable files under infra/data-factory/variables/.

## Implementation Guide

### 1. Set Up Azure DevOps

- Create a service connection in Azure DevOps (`AZURE_SUBSCRIPTION`) with Contributor and User Access Administrator permissions.
- Import or reference the core IaC library that contains:
  - `main.bicep` (ADF resource definition)
  - `data-factory.yaml` (wrapper pipeline)

### 2. Prepare Variable Files

- Navigate to `infra/data-factory/variables/`
- Create a new file for each environment (e.g., `sbox.yaml`, `dev.yaml`)
- Use the `sbox.yaml` structure as a baseline and update values for:
  - `dataFactoryName`
  - `resourceGroupName`
  - `location`
  - `gitConfigureLater`, etc.

### 3. Configure the Calling Pipeline

- Navigate to `infra/data-factory/v1/`
- Use `adf-data-ingestion-v1-iac.yaml` as the main IaC orchestration pipeline
- Reference:
  - The wrapper (`data-factory.yaml`) from the core library
  - The correct variable file for your environment

### 4. Run the Pipeline

- Go to Azure DevOps > Pipelines > Run Pipeline
- Select:
  - `targetEnvironment`: e.g., `sbox`
  - `deployAction`: `deploy` or `delete`
- Monitor the jobs: prerequisites, identity creation, ADF deployment

### 5. Verify Deployment in Azure

- Open the Azure Portal
- Check for:
  - ADF instance with correct naming (e.g., `adf-int-sbox-eastus-001`)
  - Git repository configuration (if `gitConfigureLater: false`)
  - Managed identities and diagnostic settings
  - Private endpoints (if configured)

### 6. Customize as Needed

- Add global parameters, integration runtimes, or datasets directly to `main.bicep` or reference additional templates
- Update `sbox.yaml` to configure private endpoints, tags, diagnostic settings
- Use modular Git repos to manage complex data factory assets

## Troubleshooting

| Issue                      | Resolution                                                                 |
|----------------------------|---------------------------------------------------------------------------|
| **Resource not found**     | Verify that all referenced resources like subnet, DNS zone, or workspace exist. |
| **Git not configured**     | Set `gitConfigureLater: false` and provide all required Git configuration parameters in the variable file. |
| **Diagnostic setting fails** | Ensure the Log Analytics workspace exists and the ID is correctly set in the variable file. |
| **Identity assignment fails** | Check that the user-assigned managed identity (UAMI) exists in the specified resource group. |
| **Pipeline fails on wrapper** | Confirm correct paths to core library and existence of wrapper file (`data-factory.yaml`). |
| **Missing permissions**    | Ensure the service connection has Contributor and User Access Administrator roles. |
| **Private endpoint issues** | Confirm the DNS zone and subnet are correctly configured and linked. |

## Notes

- **Wrapper Stability**: `data-factory.yaml` is a fixed wrapper. It should not require edits between environments. Keep all environment-specific settings in variable files.
- **Least Privilege Access**: Use narrowly scoped role assignments for managed identities instead of broad Contributor roles where possible.
- **Custom Tags**: Include tags in the variable file to support FinOps, ownership, and criticality metadata.
- **Git Integration**:
  - Use `gitConfigureLater: false` for automated Git repo configuration.
  - Support for Azure DevOps Git repositories is embedded.
- **Agent Pool Requirements**:
  - Must support: Azure CLI, Bicep CLI, PowerShell Core, and jq (if required).
  - Use a pre-configured self-hosted agent pool for consistency across deployments.

## Resources

- [Azure Data Factory Documentation](https://learn.microsoft.com/en-us/azure/data-factory/)
- [Bicep Language Reference](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [Azure DevOps Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/)
- [Managed Identity Documentation](https://learn.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/overview)
- [Azure Private Link](https://learn.microsoft.com/en-us/azure/private-link/private-endpoint-overview)
- [Core Library Repository](https://dev.azure.com/EASAzureCommunityofPractice/eas-azure-iac-core-library)


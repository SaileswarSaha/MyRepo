param (
    [string]$srcDir1,
    [string]$destDir,
    [string]$newWorkspace1
)

# Function to copy files and update content  
function Copy-And-UpdateFiles {  
    param (  
        [string]$srcDir,  
        [string]$destWorkspace  
    )  

    # Create destination directory if it doesn't exist  
    if (-not (Test-Path -Path $destWorkspace)) {  
        New-Item -ItemType Directory -Path $destWorkspace -Force  
    }  

    # Get all files and directories in the source directory  
    $items = Get-ChildItem -Path $srcDir -Recurse  

    foreach ($item in $items) {  
        # Construct the destination path  
        $destPath = $item.FullName.Replace($srcDir, $destWorkspace)  

        if ($item.PSIsContainer) {  
            # Create directory if it's a folder  
            if (-not (Test-Path -Path $destPath)) {  
                New-Item -ItemType Directory -Path $destPath -Force  
            }  
        } else {  
            # Copy file if it's a file  
            Copy-Item -Path $item.FullName -Destination $destPath -Force  
        }  
    }  
}  

# Resolve full paths and build destination workspace path  
$resolvedSrcDir1 = (Resolve-Path $srcDir1).Path  
$destWorkspace1 = Join-Path -Path $destDir -ChildPath $newWorkspace1  

# Call the function to copy files and update content  
Copy-And-UpdateFiles -srcDir $resolvedSrcDir1 -destWorkspace $destWorkspace1

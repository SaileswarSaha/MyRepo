#!/bin/bash

# map_service_to_workspace_artifacts.sh
#
# SYNOPSIS:
#   Maps Azure APIM artifacts extracted from a service-level instance to a workspace-level structure
#   suitable for APIOps publishing.
#
# DESCRIPTION:
#   This script takes a source directory containing APIM artifacts extracted from a service-level
#   Azure APIM instance (e.g., your Dev environment). It then selectively copies specified APIs
#   and their related components (policies, products they're linked to) into a new target directory
#   structured for a specific APIM Workspace.
#
#   This is crucial when promoting APIs from a non-workspace-aware environment to one that utilizes
#   APIM Workspaces for better organization and delegation.
#
# USAGE:
#   ./map_service_to_workspace_artifacts.sh \
#       --source-artifacts-dir "C:/Path/To/Your/DevAPIM_Extracted" \
#       --target-staging-dir "C:/Path/To/Your/ProdAPIM_WorkspaceReady" \
#       --target-workspace-name "MyTeamWorkspace" \
#       --apis-to-map "MyDevApiV1" "AnotherServiceApi"
#
# PARAMETERS:
#   --source-artifacts-dir    Path to the directory containing source APIM artifacts.
#   --target-staging-dir      Path to the directory where workspace-ready artifacts will be staged.
#   --target-workspace-name   The name of the target APIM Workspace.
#   --apis-to-map             Space-separated list of API names to map.

# --- Function to display usage ---
usage() {
    echo "Usage: $0 --source-artifacts-dir <path> --target-staging-dir <path> --target-workspace-name <name> --apis-to-map <api1> [api2 ...]"
    echo ""
    echo "Parameters:"
    echo "  --source-artifacts-dir    Path to the directory containing source APIM artifacts."
    echo "  --target-staging-dir      Path to the directory where workspace-ready artifacts will be staged."
    echo "  --target-workspace-name   The name of the target APIM Workspace."
    echo "  --apis-to-map             Space-separated list of API names to map."
    exit 1
}

# --- Parse Arguments ---
if [[ "$#" -eq 0 ]]; then
    usage
fi

while [[ "$#" -gt 0 ]]; do
    case "$1" in
        --source-artifacts-dir)
            SOURCE_ARTIFACTS_DIR="$2"
            shift 2
            ;;
        --target-staging-dir)
            TARGET_STAGING_DIR="$2"
            shift 2
            ;;
        --target-workspace-name)
            TARGET_WORKSPACE_NAME="$2"
            shift 2
            ;;
        --apis-to-map)
            shift # consume --apis-to-map
            APIS_TO_MAP=()
            while [[ "$#" -gt 0 && ! "$1" =~ ^-- ]]; do
                APIS_TO_MAP+=("$1")
                shift
            done
            ;;
        *)
            echo "Unknown parameter: $1"
            usage
            ;;
    esac
done

# Validate required parameters
if [ -z "$SOURCE_ARTIFACTS_DIR" ] || [ -z "$TARGET_STAGING_DIR" ] || [ -z "$TARGET_WORKSPACE_NAME" ] || [ ${#APIS_TO_MAP[@]} -eq 0 ]; then
    echo "Error: All parameters are required."
    usage
fi

# --- Configuration ---
APIS_SOURCE_PATH="$SOURCE_ARTIFACTS_DIR/apis"
PRODUCTS_SOURCE_PATH="$SOURCE_ARTIFACTS_DIR/products"

TARGET_WORKSPACE_PATH="$TARGET_STAGING_DIR/workspaces/$TARGET_WORKSPACE_NAME"
TARGET_APIS_PATH="$TARGET_WORKSPACE_PATH/apis"
TARGET_PRODUCTS_PATH="$TARGET_WORKSPACE_PATH/products"

echo "Starting APIM artifact mapping from service-level to workspace-level..."
echo "Source: '$SOURCE_ARTIFACTS_DIR'"
echo "Target Staging: '$TARGET_STAGING_DIR'"
echo "Target Workspace: '$TARGET_WORKSPACE_NAME'"
echo "APIs to map: ${APIS_TO_MAP[*]}"
echo "---"

# --- Script Logic ---

# 1. Create target workspace directory structure
echo "Creating target workspace directories..."
mkdir -p "$TARGET_APIS_PATH" || { echo "Error: Failed to create $TARGET_APIS_PATH"; exit 1; }
mkdir -p "$TARGET_PRODUCTS_PATH" || { echo "Error: Failed to create $TARGET_PRODUCTS_PATH"; exit 1; }
echo "Created target workspace directories: '$TARGET_APIS_PATH', '$TARGET_PRODUCTS_PATH'"

# 2. Process and copy specified APIs
COPIED_API_COUNT=0
for api_name in "${APIS_TO_MAP[@]}"; do
    SOURCE_API_FOLDER="$APIS_SOURCE_PATH/$api_name"
    
    # --- ADDED DEBUG LINE BELOW ---
    echo "DEBUG: Attempting to copy API '$api_name'. Checking source folder: '$SOURCE_API_FOLDER'" 
    # --- END ADDED DEBUG LINE ---

    if [ ! -d "$SOURCE_API_FOLDER" ]; then
        echo "Warning: API folder '$SOURCE_API_FOLDER' not found. Skipping API: '$api_name'." 
        continue
    fi

    echo "Copying API '$api_name'..."
    cp -r "$SOURCE_API_FOLDER" "$TARGET_APIS_PATH/" || { echo "Error: Failed to copy API '$api_name'"; continue; }
    COPIED_API_COUNT=$((COPIED_API_COUNT + 1))
    echo "Successfully copied API '$api_name' to '$TARGET_API_FOLDER'."
done

if [ "$COPIED_API_COUNT" -eq 0 ]; then
    echo "Warning: No APIs were copied. Please check 'apis-to-map' parameter and source directory."
else
    echo "Successfully copied $COPIED_API_COUNT API(s) to the workspace staging directory."
fi

# 3. Identify and copy relevant products
echo "---"
echo "Identifying and copying relevant products..."

COPIED_PRODUCT_COUNT=0
declare -A PRODUCTS_TO_COPY # Associative array to store unique product filenames

if [ -d "$PRODUCTS_SOURCE_PATH" ]; then
    for product_yaml_file in "$PRODUCTS_SOURCE_PATH"/*.yaml; do
        if [ -f "$product_yaml_file" ]; then
            PRODUCT_NAME=$(basename "$product_yaml_file")
            
            # Use yq to parse the product YAML and check for API links
            # Assuming product YAMLs have an 'api_ids' array under 'properties'
            # e.g., properties:
            #          api_ids:
            #          - apis/your-api-name
            LINKED_API_IDS=$(yq eval '.properties.api_ids[]' "$product_yaml_file" 2>/dev/null)
            
            # If api_ids is not found or empty, try another common structure
            if [ -z "$LINKED_API_IDS" ]; then
                LINKED_API_IDS=$(yq eval '.apis[]' "$product_yaml_file" 2>/dev/null) # For older APIOps or different structures
            fi

            for linked_id in $LINKED_API_IDS; do
                # Extract the API name from the ID (e.g., "apis/MyApi" -> "MyApi")
                api_name_from_product=$(basename "$linked_id")
                
                # Check if this linked API is one of the APIs we are mapping
                for mapped_api in "${APIS_TO_MAP[@]}"; do
                    if [ "$api_name_from_product" == "$mapped_api" ]; then
                        PRODUCTS_TO_COPY["$PRODUCT_NAME"]=1 # Mark for copying
                        break 2 # Found a match, move to next product
                    fi
                done
            done
        fi
    done

    for product_filename in "${!PRODUCTS_TO_COPY[@]}"; do
        SOURCE_PRODUCT_FILE="$PRODUCTS_SOURCE_PATH/$product_filename"
        TARGET_PRODUCT_FILE="$TARGET_PRODUCTS_PATH/$product_filename"

        echo "Copying product '$product_filename' (linked to mapped API(s))..."
        cp "$SOURCE_PRODUCT_FILE" "$TARGET_PRODUCTS_PATH/" || { echo "Error: Failed to copy product '$product_filename'"; continue; }
        COPIED_PRODUCT_COUNT=$((COPIED_PRODUCT_COUNT + 1))
        echo "Successfully copied product '$product_filename'."
    done

else
    echo "Warning: Products source path '$PRODUCTS_SOURCE_PATH' not found. Skipping product copying."
fi

if [ "$COPIED_PRODUCT_COUNT" -gt 0 ]; then
    echo "Successfully copied $COPIED_PRODUCT_COUNT product(s) linked to mapped APIs."
else
    echo "No products found linked to the specified APIs, or products source path not found."
fi

echo "---"
echo "Mapping complete. Review artifacts in '$TARGET_STAGING_DIR' before publishing."
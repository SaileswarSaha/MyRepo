
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Check, Database, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export const CustomObjectGenerator = () => {
  const [objectName, setObjectName] = useState("");
  const [objectType, setObjectType] = useState("");
  const [namespace, setNamespace] = useState("");
  const [generatedName, setGeneratedName] = useState("");
  const [apiName, setApiName] = useState("");
  const [copied, setCopied] = useState(false);

  const generateNames = () => {
    if (!objectName.trim()) return;

    // Convert to Pascal Case for display name
    const words = objectName.toLowerCase().split(/[\s_-]+/);
    const pascalCase = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join('');
    
    // Generate API name
    let api = pascalCase;
    if (namespace) {
      api = `${namespace}__${pascalCase}__c`;
    } else {
      api = `${pascalCase}__c`;
    }

    setGeneratedName(pascalCase);
    setApiName(api);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy to clipboard");
    }
  };

  const validateName = () => {
    const issues = [];
    if (objectName.length > 40) issues.push("Name should be under 40 characters");
    if (/^\d/.test(objectName)) issues.push("Cannot start with a number");
    if (/[^a-zA-Z0-9\s_-]/.test(objectName)) issues.push("Contains invalid characters");
    return issues;
  };

  const validationIssues = validateName();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="h-5 w-5 text-blue-600" />
            <span>Custom Object Naming Generator</span>
          </CardTitle>
          <CardDescription>
            Generate Salesforce custom object names following best practices and naming conventions.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="objectName">Object Name</Label>
                <Input
                  id="objectName"
                  placeholder="e.g., Customer Account, Project Task"
                  value={objectName}
                  onChange={(e) => setObjectName(e.target.value)}
                  className="mt-1"
                />
                {validationIssues.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {validationIssues.map((issue, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        <span>{issue}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="objectType">Object Type</Label>
                <Select value={objectType} onValueChange={setObjectType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select object type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard Object Extension</SelectItem>
                    <SelectItem value="custom">Custom Object</SelectItem>
                    <SelectItem value="external">External Object</SelectItem>
                    <SelectItem value="junction">Junction Object</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="namespace">Namespace (Optional)</Label>
                <Input
                  id="namespace"
                  placeholder="e.g., MyApp"
                  value={namespace}
                  onChange={(e) => setNamespace(e.target.value)}
                  className="mt-1"
                />
              </div>

              <Button 
                onClick={generateNames} 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!objectName.trim() || validationIssues.length > 0}
              >
                Generate Names
              </Button>
            </div>

            <div className="space-y-4">
              {generatedName && (
                <div className="space-y-4">
                  <div>
                    <Label>Display Name</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{generatedName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(generatedName)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>API Name</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{apiName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(apiName)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Naming Rules Applied</Label>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">PascalCase</Badge>
                      <Badge variant="secondary">__c suffix</Badge>
                      {namespace && <Badge variant="secondary">Namespaced</Badge>}
                      <Badge variant="secondary">No spaces</Badge>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Custom Object Naming Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-700 mb-2">✅ Do</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use descriptive, business-friendly names</li>
                <li>• Use PascalCase (CustomerAccount)</li>
                <li>• Keep names under 40 characters</li>
                <li>• Use singular nouns (Account, not Accounts)</li>
                <li>• Be consistent across your org</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-red-700 mb-2">❌ Don't</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use abbreviations or acronyms</li>
                <li>• Start with numbers</li>
                <li>• Use special characters</li>
                <li>• Use Salesforce reserved words</li>
                <li>• Create overly long names</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};


import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Check, GitBranch, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export const FlowGenerator = () => {
  const [flowName, setFlowName] = useState("");
  const [flowType, setFlowType] = useState("");
  const [triggerObject, setTriggerObject] = useState("");
  const [generatedName, setGeneratedName] = useState("");
  const [apiName, setApiName] = useState("");
  const [copied, setCopied] = useState(false);

  const generateNames = () => {
    if (!flowName.trim()) return;

    // Generate human-readable name
    const words = flowName.toLowerCase().split(/[\s_-]+/);
    const displayName = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    
    // Generate API name (no spaces, underscores for flows)
    const apiNameParts = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
    let api = apiNameParts.join('_');
    
    // Add object prefix for record-triggered flows
    if ((flowType === 'record-triggered' || flowType === 'platform-event') && triggerObject) {
      const objectPrefix = triggerObject.replace(/\s+/g, '');
      api = `${objectPrefix}_${api}`;
    }

    setGeneratedName(displayName);
    setApiName(api);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy to clipboard");
    }
  };

  const validateName = () => {
    const issues = [];
    if (flowName.length > 50) issues.push("Name should be under 50 characters");
    if (/^\d/.test(flowName)) issues.push("Cannot start with a number");
    if (/[^a-zA-Z0-9\s_-]/.test(flowName)) issues.push("Contains invalid characters");
    return issues;
  };

  const validationIssues = validateName();

  const getFlowTypeDescription = () => {
    const descriptions = {
      "screen-flow": "Interactive flows with user interface screens",
      "record-triggered": "Flows that run when records are created, updated, or deleted",
      "scheduled": "Flows that run on a time-based schedule",
      "platform-event": "Flows triggered by platform events",
      "autolaunched": "Flows that can be called from other processes",
      "chat": "Flows used in Einstein Bot conversations"
    };
    return flowType ? descriptions[flowType as keyof typeof descriptions] : "";
  };

  const getFlowPrefix = () => {
    const prefixes = {
      "screen-flow": "SF",
      "record-triggered": "RT", 
      "scheduled": "SCH",
      "platform-event": "PE",
      "autolaunched": "AL",
      "chat": "CB"
    };
    return flowType ? prefixes[flowType as keyof typeof prefixes] : "";
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <GitBranch className="h-5 w-5 text-blue-600" />
            <span>Flow Naming Generator</span>
          </CardTitle>
          <CardDescription>
            Generate Salesforce Flow names following best practices for different flow types and triggers.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="flowName">Flow Purpose/Name</Label>
                <Input
                  id="flowName"
                  placeholder="e.g., Update Account Status, Send Welcome Email"
                  value={flowName}
                  onChange={(e) => setFlowName(e.target.value)}
                  className="mt-1"
                />
                {validationIssues.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {validationIssues.map((issue, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        <span>{issue}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="flowType">Flow Type</Label>
                <Select value={flowType} onValueChange={setFlowType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select flow type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="screen-flow">Screen Flow</SelectItem>
                    <SelectItem value="record-triggered">Record-Triggered Flow</SelectItem>
                    <SelectItem value="scheduled">Scheduled Flow</SelectItem>
                    <SelectItem value="platform-event">Platform Event Flow</SelectItem>
                    <SelectItem value="autolaunched">Autolaunched Flow</SelectItem>
                    <SelectItem value="chat">Chat Bot Flow</SelectItem>
                  </SelectContent>
                </Select>
                {flowType && (
                  <p className="text-sm text-gray-600 mt-1">{getFlowTypeDescription()}</p>
                )}
              </div>

              {(flowType === 'record-triggered' || flowType === 'platform-event') && (
                <div>
                  <Label htmlFor="triggerObject">Trigger Object</Label>
                  <Input
                    id="triggerObject"
                    placeholder="e.g., Account, Contact, Opportunity"
                    value={triggerObject}
                    onChange={(e) => setTriggerObject(e.target.value)}
                    className="mt-1"
                  />
                </div>
              )}

              <Button 
                onClick={generateNames} 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!flowName.trim() || !flowType || validationIssues.length > 0}
              >
                Generate Flow Names
              </Button>
            </div>

            <div className="space-y-4">
              {generatedName && (
                <div className="space-y-4">
                  <div>
                    <Label>Display Name</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{generatedName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(generatedName)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>API Name</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{apiName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(apiName)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Flow Characteristics</Label>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">{flowType}</Badge>
                      {getFlowPrefix() && <Badge variant="secondary">{getFlowPrefix()} prefix</Badge>}
                      <Badge variant="secondary">Descriptive</Badge>
                      <Badge variant="secondary">Action-oriented</Badge>
                      {triggerObject && <Badge variant="secondary">{triggerObject} triggered</Badge>}
                    </div>
                  </div>

                  <div className="p-3 bg-blue-50 rounded-md border border-blue-200">
                    <h4 className="text-sm font-semibold text-blue-800 mb-2">Flow Design Tips:</h4>
                    <ul className="text-xs text-blue-700 space-y-1">
                      <li>• Use clear, action-based names</li>
                      <li>• Include the object name for record-triggered flows</li>
                      <li>• Use consistent naming patterns across your org</li>
                      <li>• Consider the flow's trigger timing (before/after save)</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Flow Naming Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-700 mb-2">✅ Do</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use action verbs (Update, Send, Create)</li>
                <li>• Include the object name for triggers</li>
                <li>• Be specific about the purpose</li>
                <li>• Use consistent naming patterns</li>
                <li>• Keep names under 50 characters</li>
                <li>• Use proper capitalization in labels</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-red-700 mb-2">❌ Don't</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use vague names like "Process Records"</li>
                <li>• Include "Flow" in the name</li>
                <li>• Use technical jargon</li>
                <li>• Create overly long descriptive names</li>
                <li>• Use different naming styles in same org</li>
                <li>• Forget to specify the trigger timing</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

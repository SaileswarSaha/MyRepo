
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Check, GitBranch, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export const CustomFieldGenerator = () => {
  const [fieldName, setFieldName] = useState("");
  const [fieldType, setFieldType] = useState("");
  const [namespace, setNamespace] = useState("");
  const [generatedLabel, setGeneratedLabel] = useState("");
  const [apiName, setApiName] = useState("");
  const [copied, setCopied] = useState(false);

  const generateNames = () => {
    if (!fieldName.trim()) return;

    // Generate field label (human readable)
    const words = fieldName.toLowerCase().split(/[\s_-]+/);
    const label = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    
    // Generate API name (no spaces, PascalCase with __c)
    const pascalCase = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join('');
    let api = pascalCase;
    
    if (namespace) {
      api = `${namespace}__${pascalCase}__c`;
    } else {
      api = `${pascalCase}__c`;
    }

    setGeneratedLabel(label);
    setApiName(api);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy to clipboard");
    }
  };

  const validateName = () => {
    const issues = [];
    if (fieldName.length > 40) issues.push("Name should be under 40 characters");
    if (/^\d/.test(fieldName)) issues.push("Cannot start with a number");
    if (/[^a-zA-Z0-9\s_-]/.test(fieldName)) issues.push("Contains invalid characters");
    return issues;
  };

  const validationIssues = validateName();

  const getFieldTypeGuidance = () => {
    const guidance = {
      text: "Use for short text values (up to 255 characters)",
      textarea: "Use for longer text content",
      number: "Use for numeric calculations and sorting",
      currency: "Use for monetary values",
      date: "Use for date-only values",
      datetime: "Use for date and time values",
      checkbox: "Use for true/false values",
      picklist: "Use for predefined list of values",
      lookup: "Use to reference another object",
      formula: "Use for calculated values",
      rollup: "Use for summarizing child records"
    };
    return fieldType ? guidance[fieldType as keyof typeof guidance] : "";
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <GitBranch className="h-5 w-5 text-blue-600" />
            <span>Custom Field Naming Generator</span>
          </CardTitle>
          <CardDescription>
            Generate Salesforce custom field names with proper labels and API names.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="fieldName">Field Name</Label>
                <Input
                  id="fieldName"
                  placeholder="e.g., Customer Priority, Last Contact Date"
                  value={fieldName}
                  onChange={(e) => setFieldName(e.target.value)}
                  className="mt-1"
                />
                {validationIssues.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {validationIssues.map((issue, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        <span>{issue}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="fieldType">Field Type</Label>
                <Select value={fieldType} onValueChange={setFieldType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select field type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="text">Text</SelectItem>
                    <SelectItem value="textarea">Text Area</SelectItem>
                    <SelectItem value="number">Number</SelectItem>
                    <SelectItem value="currency">Currency</SelectItem>
                    <SelectItem value="date">Date</SelectItem>
                    <SelectItem value="datetime">Date/Time</SelectItem>
                    <SelectItem value="checkbox">Checkbox</SelectItem>
                    <SelectItem value="picklist">Picklist</SelectItem>
                    <SelectItem value="lookup">Lookup</SelectItem>
                    <SelectItem value="formula">Formula</SelectItem>
                    <SelectItem value="rollup">Roll-Up Summary</SelectItem>
                  </SelectContent>
                </Select>
                {fieldType && (
                  <p className="text-sm text-gray-600 mt-1">{getFieldTypeGuidance()}</p>
                )}
              </div>

              <div>
                <Label htmlFor="namespace">Namespace (Optional)</Label>
                <Input
                  id="namespace"
                  placeholder="e.g., MyApp"
                  value={namespace}
                  onChange={(e) => setNamespace(e.target.value)}
                  className="mt-1"
                />
              </div>

              <Button 
                onClick={generateNames} 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!fieldName.trim() || validationIssues.length > 0}
              >
                Generate Names
              </Button>
            </div>

            <div className="space-y-4">
              {generatedLabel && (
                <div className="space-y-4">
                  <div>
                    <Label>Field Label</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{generatedLabel}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(generatedLabel)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>API Name</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{apiName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(apiName)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Naming Rules Applied</Label>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">PascalCase API</Badge>
                      <Badge variant="secondary">Human Readable Label</Badge>
                      <Badge variant="secondary">__c suffix</Badge>
                      {namespace && <Badge variant="secondary">Namespaced</Badge>}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Custom Field Naming Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-700 mb-2">✅ Do</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use descriptive, clear names</li>
                <li>• Follow business terminology</li>
                <li>• Use proper capitalization in labels</li>
                <li>• Be consistent with similar fields</li>
                <li>• Include units when relevant (Amount USD)</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-red-700 mb-2">❌ Don't</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use technical jargon in labels</li>
                <li>• Create ambiguous names</li>
                <li>• Use different names for same concept</li>
                <li>• Include "Field" in the name</li>
                <li>• Use overly abbreviated names</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

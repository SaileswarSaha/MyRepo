
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Check, Zap, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export const LightningComponentGenerator = () => {
  const [componentName, setComponentName] = useState("");
  const [componentType, setComponentType] = useState("");
  const [namespace, setNamespace] = useState("");
  const [generatedName, setGeneratedName] = useState("");
  const [fileName, setFileName] = useState("");
  const [copied, setCopied] = useState(false);

  const generateNames = () => {
    if (!componentName.trim()) return;

    // Convert to camelCase for Lightning components
    const words = componentName.toLowerCase().split(/[\s_-]+/);
    const camelCase = words[0] + words.slice(1).map(word => word.charAt(0).toUpperCase() + word.slice(1)).join('');
    
    // Lightning components use camelCase
    setGeneratedName(camelCase);
    setFileName(camelCase);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy to clipboard");
    }
  };

  const validateName = () => {
    const issues = [];
    if (componentName.length > 40) issues.push("Name should be under 40 characters");
    if (/^\d/.test(componentName)) issues.push("Cannot start with a number");
    if (/[^a-zA-Z0-9\s_-]/.test(componentName)) issues.push("Contains invalid characters");
    return issues;
  };

  const validationIssues = validateName();

  const getComponentTypeDescription = () => {
    const descriptions = {
      utility: "Reusable utility component for common functionality",
      display: "Component for displaying data or information",
      input: "Component for user input and form handling",
      navigation: "Component for navigation and routing",
      modal: "Modal dialog or popup component",
      card: "Card-style display component",
      list: "Component for displaying lists of data",
      chart: "Data visualization and chart component"
    };
    return componentType ? descriptions[componentType as keyof typeof descriptions] : "";
  };

  const getFileStructure = () => {
    if (!generatedName) return [];
    
    return [
      `${generatedName}.html`,
      `${generatedName}.js`,
      `${generatedName}.css`,
      `${generatedName}.js-meta.xml`
    ];
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-blue-600" />
            <span>Lightning Component Naming Generator</span>
          </CardTitle>
          <CardDescription>
            Generate Lightning Web Component (LWC) and Aura component names following Salesforce conventions.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="componentName">Component Name</Label>
                <Input
                  id="componentName"
                  placeholder="e.g., Account Summary, Contact List"
                  value={componentName}
                  onChange={(e) => setComponentName(e.target.value)}
                  className="mt-1"
                />
                {validationIssues.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {validationIssues.map((issue, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        <span>{issue}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="componentType">Component Type</Label>
                <Select value={componentType} onValueChange={setComponentType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select component type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="utility">Utility Component</SelectItem>
                    <SelectItem value="display">Display Component</SelectItem>
                    <SelectItem value="input">Input Component</SelectItem>
                    <SelectItem value="navigation">Navigation Component</SelectItem>
                    <SelectItem value="modal">Modal Component</SelectItem>
                    <SelectItem value="card">Card Component</SelectItem>
                    <SelectItem value="list">List Component</SelectItem>
                    <SelectItem value="chart">Chart Component</SelectItem>
                  </SelectContent>
                </Select>
                {componentType && (
                  <p className="text-sm text-gray-600 mt-1">{getComponentTypeDescription()}</p>
                )}
              </div>

              <div>
                <Label htmlFor="namespace">Namespace (Optional)</Label>
                <Input
                  id="namespace"
                  placeholder="e.g., c (default)"
                  value={namespace}
                  onChange={(e) => setNamespace(e.target.value)}
                  className="mt-1"
                />
              </div>

              <Button 
                onClick={generateNames} 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!componentName.trim() || validationIssues.length > 0}
              >
                Generate Component Name
              </Button>
            </div>

            <div className="space-y-4">
              {generatedName && (
                <div className="space-y-4">
                  <div>
                    <Label>Component Name</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{generatedName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(generatedName)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>File Structure</Label>
                    <div className="mt-1 space-y-2">
                      {getFileStructure().map((file, index) => (
                        <div key={index} className="p-2 bg-gray-50 rounded border flex items-center justify-between text-sm">
                          <span className="font-mono">{file}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(file)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label>Usage in Markup</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border">
                      <code className="text-sm">&lt;{namespace || 'c'}-{generatedName}&gt;&lt;/{namespace || 'c'}-{generatedName}&gt;</code>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Naming Rules Applied</Label>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">camelCase</Badge>
                      <Badge variant="secondary">Descriptive</Badge>
                      <Badge variant="secondary">No spaces</Badge>
                      <Badge variant="secondary">Kebab-case in markup</Badge>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Lightning Component Naming Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-700 mb-2">✅ Do</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use camelCase (accountSummary)</li>
                <li>• Use descriptive, purpose-driven names</li>
                <li>• Keep names concise but clear</li>
                <li>• Use consistent naming across components</li>
                <li>• Follow HTML custom element standards</li>
                <li>• Use kebab-case in markup</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-red-700 mb-2">❌ Don't</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use PascalCase (AccountSummary)</li>
                <li>• Start with uppercase letters</li>
                <li>• Use underscores or special characters</li>
                <li>• Create overly long names</li>
                <li>• Use abbreviations unnecessarily</li>
                <li>• Conflict with HTML element names</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

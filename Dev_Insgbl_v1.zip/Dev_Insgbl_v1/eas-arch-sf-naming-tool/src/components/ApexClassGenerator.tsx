
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Copy, Check, Code, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export const ApexClassGenerator = () => {
  const [className, setClassName] = useState("");
  const [classType, setClassType] = useState("");
  const [namespace, setNamespace] = useState("");
  const [generatedName, setGeneratedName] = useState("");
  const [methodSuggestions, setMethodSuggestions] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  const generateNames = () => {
    if (!className.trim()) return;

    // Convert to PascalCase
    const words = className.toLowerCase().split(/[\s_-]+/);
    let pascalCase = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join('');
    
    // Add appropriate suffix based on class type
    const suffixes = {
      controller: "Controller",
      service: "Service",
      handler: "Handler",
      utility: "Util",
      test: "Test",
      batch: "Batch",
      scheduler: "Scheduler",
      trigger: "TriggerHandler",
      selector: "Selector",
      domain: ""
    };

    const suffix = suffixes[classType as keyof typeof suffixes] || "";
    if (suffix && !pascalCase.endsWith(suffix)) {
      pascalCase += suffix;
    }

    setGeneratedName(pascalCase);

    // Generate method suggestions based on class type
    const methodSuggestions = {
      controller: ["doSave", "doCancel", "handleSubmit", "validateInput"],
      service: ["processData", "handleBusinessLogic", "validateRequest", "executeOperation"],
      handler: ["handleBeforeInsert", "handleAfterUpdate", "handleBeforeDelete", "handleAfterDelete"],
      utility: ["formatData", "validateInput", "convertData", "processCollection"],
      test: ["testPositiveScenario", "testNegativeScenario", "testBulkData", "testExceptionHandling"],
      batch: ["execute", "finish", "start"],
      scheduler: ["execute"],
      trigger: ["handleTrigger", "processRecords"],
      selector: ["selectById", "selectByName", "selectWithFilters"],
      domain: ["validate", "handleLogic", "processRules"]
    };

    setMethodSuggestions(methodSuggestions[classType as keyof typeof methodSuggestions] || []);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy to clipboard");
    }
  };

  const validateName = () => {
    const issues = [];
    if (className.length > 40) issues.push("Name should be under 40 characters");
    if (/^\d/.test(className)) issues.push("Cannot start with a number");
    if (/[^a-zA-Z0-9\s_-]/.test(className)) issues.push("Contains invalid characters");
    return issues;
  };

  const validationIssues = validateName();

  const getClassTypeDescription = () => {
    const descriptions = {
      controller: "Handles user interface logic and user actions",
      service: "Contains business logic and complex operations",
      handler: "Manages trigger logic and database operations",
      utility: "Provides reusable helper methods",
      test: "Contains unit tests for other classes",
      batch: "Processes large datasets asynchronously",
      scheduler: "Schedules and runs automated jobs",
      trigger: "Handles trigger events (deprecated pattern)",
      selector: "Encapsulates SOQL queries (FFLIB pattern)",
      domain: "Contains business logic for specific objects (FFLIB pattern)"
    };
    return classType ? descriptions[classType as keyof typeof descriptions] : "";
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Code className="h-5 w-5 text-blue-600" />
            <span>Apex Class Naming Generator</span>
          </CardTitle>
          <CardDescription>
            Generate Apex class names following Salesforce development best practices and design patterns.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="className">Class Purpose/Name</Label>
                <Input
                  id="className"
                  placeholder="e.g., Account Management, Email Processor"
                  value={className}
                  onChange={(e) => setClassName(e.target.value)}
                  className="mt-1"
                />
                {validationIssues.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {validationIssues.map((issue, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        <span>{issue}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label htmlFor="classType">Class Type</Label>
                <Select value={classType} onValueChange={setClassType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select class type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="controller">Controller</SelectItem>
                    <SelectItem value="service">Service</SelectItem>
                    <SelectItem value="handler">Handler</SelectItem>
                    <SelectItem value="utility">Utility</SelectItem>
                    <SelectItem value="test">Test Class</SelectItem>
                    <SelectItem value="batch">Batch Class</SelectItem>
                    <SelectItem value="scheduler">Scheduler</SelectItem>
                    <SelectItem value="selector">Selector (FFLIB)</SelectItem>
                    <SelectItem value="domain">Domain (FFLIB)</SelectItem>
                  </SelectContent>
                </Select>
                {classType && (
                  <p className="text-sm text-gray-600 mt-1">{getClassTypeDescription()}</p>
                )}
              </div>

              <div>
                <Label htmlFor="namespace">Namespace (Optional)</Label>
                <Input
                  id="namespace"
                  placeholder="e.g., MyApp"
                  value={namespace}
                  onChange={(e) => setNamespace(e.target.value)}
                  className="mt-1"
                />
              </div>

              <Button 
                onClick={generateNames} 
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!className.trim() || !classType || validationIssues.length > 0}
              >
                Generate Class Name
              </Button>
            </div>

            <div className="space-y-4">
              {generatedName && (
                <div className="space-y-4">
                  <div>
                    <Label>Class Name</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded-md border flex items-center justify-between">
                      <span className="font-mono text-sm">{generatedName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(generatedName)}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  {methodSuggestions.length > 0 && (
                    <div>
                      <Label>Suggested Method Names</Label>
                      <div className="mt-1 space-y-2">
                        {methodSuggestions.map((method, index) => (
                          <div key={index} className="p-2 bg-gray-50 rounded border flex items-center justify-between text-sm">
                            <span className="font-mono">{method}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => copyToClipboard(method)}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label>Naming Rules Applied</Label>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">PascalCase</Badge>
                      {classType && <Badge variant="secondary">{classType} pattern</Badge>}
                      <Badge variant="secondary">Descriptive</Badge>
                      <Badge variant="secondary">No abbreviations</Badge>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Apex Class Naming Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-700 mb-2">✅ Do</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use PascalCase (AccountController)</li>
                <li>• Use descriptive, purpose-driven names</li>
                <li>• Follow design pattern suffixes</li>
                <li>• Keep names under 40 characters</li>
                <li>• Use singular nouns (Account, not Accounts)</li>
                <li>• Include Test suffix for test classes</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-red-700 mb-2">❌ Don't</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use abbreviations or acronyms</li>
                <li>• Start with lowercase letters</li>
                <li>• Use underscores or hyphens</li>
                <li>• Create overly generic names</li>
                <li>• Use Apex reserved words</li>
                <li>• Mix naming conventions</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

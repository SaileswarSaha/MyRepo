
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, CheckCircle, XCircle, AlertTriangle, Lightbulb } from "lucide-react";

export const BestPracticesGuide = () => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-blue-600" />
            <span>Salesforce Naming Conventions Best Practices Guide</span>
          </CardTitle>
          <CardDescription>
            Comprehensive guide to naming conventions across all Salesforce development components.
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="general">General Rules</TabsTrigger>
          <TabsTrigger value="objects">Objects & Fields</TabsTrigger>
          <TabsTrigger value="code">Code & Classes</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="examples">Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span>Universal Naming Principles</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-green-700 flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Essential Guidelines</span>
                  </h3>
                  <ul className="space-y-2 text-sm">
                    <li>• <strong>Be Descriptive:</strong> Names should clearly indicate purpose</li>
                    <li>• <strong>Be Consistent:</strong> Use the same patterns throughout your org</li>
                    <li>• <strong>Be Concise:</strong> Avoid unnecessarily long names</li>
                    <li>• <strong>Use Business Language:</strong> Match terminology users understand</li>
                    <li>• <strong>Avoid Abbreviations:</strong> Write out full words when possible</li>
                    <li>• <strong>Plan for Scale:</strong> Consider how names work with multiple records</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="font-semibold text-red-700 flex items-center space-x-2">
                    <XCircle className="h-4 w-4" />
                    <span>Common Mistakes</span>
                  </h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Using technical jargon instead of business terms</li>
                    <li>• Inconsistent capitalization patterns</li>
                    <li>• Over-abbreviating names (Acct instead of Account)</li>
                    <li>• Using different naming styles in same org</li>
                    <li>• Creating names that are too generic</li>
                    <li>• Not considering future maintenance</li>
                  </ul>
                </div>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h4 className="font-semibold text-blue-800 mb-2 flex items-center space-x-2">
                  <Lightbulb className="h-4 w-4" />
                  <span>Pro Tip: Documentation</span>
                </h4>
                <p className="text-blue-700 text-sm">
                  Always document your naming conventions in a shared location. Include examples, 
                  exceptions, and the reasoning behind your choices. This helps maintain consistency 
                  as your team grows.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="objects" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Custom Objects</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Naming Pattern</h4>
                  <Badge variant="outline" className="font-mono">PascalCase__c</Badge>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Examples</h4>
                  <ul className="text-sm space-y-1">
                    <li>• <code>ProjectTask__c</code></li>
                    <li>• <code>CustomerAccount__c</code></li>
                    <li>• <code>ProductCatalog__c</code></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Key Rules</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Use singular nouns</li>
                    <li>• No spaces or special characters</li>
                    <li>• Maximum 40 characters</li>
                    <li>• Must end with __c</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Custom Fields</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Naming Pattern</h4>
                  <Badge variant="outline" className="font-mono">Field_Name__c</Badge>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Examples</h4>
                  <ul className="text-sm space-y-1">
                    <li>• <code>Customer_Priority__c</code></li>
                    <li>• <code>Last_Contact_Date__c</code></li>
                    <li>• <code>Annual_Revenue__c</code></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Key Rules</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Use underscores for readability</li>
                    <li>• Field Label should be human-readable</li>
                    <li>• Be descriptive but concise</li>
                    <li>• Include data type context when helpful</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="code" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Apex Classes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Naming Patterns</h4>
                  <div className="space-y-2">
                    <div><Badge variant="outline">Controller</Badge> - PascalCaseController</div>
                    <div><Badge variant="outline">Service</Badge> - PascalCaseService</div>
                    <div><Badge variant="outline">Handler</Badge> - PascalCaseHandler</div>
                    <div><Badge variant="outline">Utility</Badge> - PascalCaseUtil</div>
                    <div><Badge variant="outline">Test</Badge> - PascalCaseTest</div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Examples</h4>
                  <ul className="text-sm space-y-1">
                    <li>• <code>AccountController</code></li>
                    <li>• <code>EmailService</code></li>
                    <li>• <code>OpportunityTriggerHandler</code></li>
                    <li>• <code>DateUtil</code></li>
                    <li>• <code>AccountControllerTest</code></li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lightning Components</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Naming Pattern</h4>
                  <Badge variant="outline" className="font-mono">camelCase</Badge>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Examples</h4>
                  <ul className="text-sm space-y-1">
                    <li>• <code>accountSummary</code></li>
                    <li>• <code>contactList</code></li>
                    <li>• <code>opportunityCard</code></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Usage in Markup</h4>
                  <ul className="text-sm space-y-1">
                    <li>• <code>&lt;c-account-summary&gt;</code></li>
                    <li>• <code>&lt;c-contact-list&gt;</code></li>
                    <li>• <code>&lt;c-opportunity-card&gt;</code></li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="automation" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Flows</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Naming Pattern</h4>
                  <Badge variant="outline" className="font-mono">[Object] [Action] [Description]</Badge>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Examples</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Account Update Credit Score</li>
                    <li>• Contact Send Welcome Email</li>
                    <li>• Opportunity Calculate Commission</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Flow Types</h4>
                  <ul className="text-sm space-y-1">
                    <li>• <strong>Screen Flow:</strong> User interaction flows</li>
                    <li>• <strong>Record-Triggered:</strong> Automated on record changes</li>
                    <li>• <strong>Scheduled:</strong> Time-based automation</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Process Builder & Workflows</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Legacy Tools</h4>
                  <div className="p-3 bg-yellow-50 rounded border border-yellow-200">
                    <p className="text-sm text-yellow-800">
                      <AlertTriangle className="h-4 w-4 inline mr-1" />
                      Process Builder and Workflow Rules are legacy tools. 
                      Use Flows for new automation.
                    </p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Migration Strategy</h4>
                  <ul className="text-sm space-y-1">
                    <li>• Audit existing Process Builder processes</li>
                    <li>• Plan migration to Flows</li>
                    <li>• Use consistent naming during transition</li>
                    <li>• Document changes for team awareness</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="examples" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Real-World Naming Examples</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-3">Sales Cloud Implementation</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-green-700 mb-2">✅ Good Examples</h4>
                      <ul className="text-sm space-y-1 font-mono">
                        <li>• CustomerAccount__c</li>
                        <li>• OpportunityStage__c</li>
                        <li>• SalesRepController</li>
                        <li>• Account Update Territory</li>
                        <li>• opportunityCard</li>
                        <li>• Customer_Priority__c</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-red-700 mb-2">❌ Poor Examples</h4>
                      <ul className="text-sm space-y-1 font-mono">
                        <li>• CustAcct__c</li>
                        <li>• OppStg__c</li>
                        <li>• SalesController</li>
                        <li>• Update Territory</li>
                        <li>• OppCard</li>
                        <li>• Cust_Pri__c</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Service Cloud Implementation</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-green-700 mb-2">✅ Good Examples</h4>
                      <ul className="text-sm space-y-1 font-mono">
                        <li>• ServiceRequest__c</li>
                        <li>• KnowledgeArticle__c</li>
                        <li>• CaseEscalationHandler</li>
                        <li>• Case Auto-Assign to Queue</li>
                        <li>• caseDetailView</li>
                        <li>• Escalation_Reason__c</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-red-700 mb-2">❌ Poor Examples</h4>
                      <ul className="text-sm space-y-1 font-mono">
                        <li>• SvcReq__c</li>
                        <li>• KB__c</li>
                        <li>• CaseHandler</li>
                        <li>• Auto-Assign</li>
                        <li>• caseView</li>
                        <li>• Esc_Rsn__c</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <h4 className="font-semibold text-green-800 mb-2">Naming Convention Checklist</h4>
                  <ul className="text-green-700 text-sm space-y-1">
                    <li>✓ Names are descriptive and business-friendly</li>
                    <li>✓ Consistent patterns used across similar components</li>
                    <li>✓ Proper capitalization for each component type</li>
                    <li>✓ No unnecessary abbreviations</li>
                    <li>✓ Names indicate purpose and context</li>
                    <li>✓ Future maintainers can understand the purpose</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

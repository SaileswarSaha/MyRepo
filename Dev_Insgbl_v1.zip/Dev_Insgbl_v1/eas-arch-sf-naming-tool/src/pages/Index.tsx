
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CustomObjectGenerator } from "@/components/CustomObjectGenerator";
import { CustomFieldGenerator } from "@/components/CustomFieldGenerator";
import { ApexClassGenerator } from "@/components/ApexClassGenerator";
import { LightningComponentGenerator } from "@/components/LightningComponentGenerator";
import { FlowGenerator } from "@/components/FlowGenerator";
import { BestPracticesGuide } from "@/components/BestPracticesGuide";
import { Cloud, Database, Code, Zap, GitBranch, BookOpen } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center space-x-3">
            <Cloud className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Salesforce Naming Conventions</h1>
              <p className="text-gray-600">Generate consistent, best-practice naming for your Salesforce development</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="custom-objects" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-white shadow-sm rounded-lg p-1">
            <TabsTrigger value="custom-objects" className="flex items-center space-x-2">
              <Database className="h-4 w-4" />
              <span className="hidden sm:inline">Objects</span>
            </TabsTrigger>
            <TabsTrigger value="custom-fields" className="flex items-center space-x-2">
              <GitBranch className="h-4 w-4" />
              <span className="hidden sm:inline">Fields</span>
            </TabsTrigger>
            <TabsTrigger value="apex-classes" className="flex items-center space-x-2">
              <Code className="h-4 w-4" />
              <span className="hidden sm:inline">Apex</span>
            </TabsTrigger>
            <TabsTrigger value="lightning-components" className="flex items-center space-x-2">
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Lightning</span>
            </TabsTrigger>
            <TabsTrigger value="flows" className="flex items-center space-x-2">
              <GitBranch className="h-4 w-4" />
              <span className="hidden sm:inline">Flows</span>
            </TabsTrigger>
            <TabsTrigger value="best-practices" className="flex items-center space-x-2">
              <BookOpen className="h-4 w-4" />
              <span className="hidden sm:inline">Guide</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Cloud className="h-5 w-5" />
                  <span>Salesforce Standards</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-blue-100">Follow official Salesforce naming conventions for consistency and maintainability.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="h-5 w-5" />
                  <span>Quick Generation</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-green-100">Generate properly formatted names instantly with real-time validation and suggestions.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5" />
                  <span>Best Practices</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-purple-100">Learn industry standards and avoid common naming pitfalls in Salesforce development.</p>
              </CardContent>
            </Card>
          </div>

          {/* Tab Contents */}
          <TabsContent value="custom-objects">
            <CustomObjectGenerator />
          </TabsContent>
          
          <TabsContent value="custom-fields">
            <CustomFieldGenerator />
          </TabsContent>
          
          <TabsContent value="apex-classes">
            <ApexClassGenerator />
          </TabsContent>
          
          <TabsContent value="lightning-components">
            <LightningComponentGenerator />
          </TabsContent>
          
          <TabsContent value="flows">
            <FlowGenerator />
          </TabsContent>
          
          <TabsContent value="best-practices">
            <BestPracticesGuide />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Index;

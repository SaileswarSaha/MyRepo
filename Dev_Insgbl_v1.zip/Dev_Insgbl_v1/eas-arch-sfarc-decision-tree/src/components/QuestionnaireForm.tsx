import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, CheckCircle } from "lucide-react";
import { QuestionnaireResults } from "./QuestionnaireResults";

interface Question {
  id: string;
  category: string;
  question: string;
  options: { value: string; label: string; solutionScore: number; technicalScore: number; }[];
}

const questions: Question[] = [
  // Change Type & Business Impact (Questions 1-4)
  {
    id: "change_type",
    category: "Change Type & Business Impact",
    question: "What type of Salesforce change is being requested?",
    options: [
      { value: "new_development", label: "New Development - Building new features/functionality", solutionScore: 4, technicalScore: 3 },
      { value: "enhancement", label: "Enhancement - Modifying existing functionality", solutionScore: 3, technicalScore: 3 },
      { value: "production_incident", label: "Production Incident - Fixing critical issues", solutionScore: 1, technicalScore: 5 },
      { value: "maintenance", label: "Maintenance - Regular updates/patches", solutionScore: 2, technicalScore: 4 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "business_impact",
    category: "Change Type & Business Impact",
    question: "What is the business impact level of this change?",
    options: [
      { value: "critical", label: "Critical - Business operations stopped/severely impacted", solutionScore: 2, technicalScore: 5 },
      { value: "high", label: "High - Significant business process disruption", solutionScore: 4, technicalScore: 4 },
      { value: "medium", label: "Medium - Moderate impact on business efficiency", solutionScore: 4, technicalScore: 3 },
      { value: "low", label: "Low - Minor impact, nice-to-have improvement", solutionScore: 3, technicalScore: 2 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "stakeholder_complexity",
    category: "Change Type & Business Impact",
    question: "How many business stakeholders/departments are affected by this change?",
    options: [
      { value: "single_user", label: "Single user or small team", solutionScore: 2, technicalScore: 1 },
      { value: "single_department", label: "Single department", solutionScore: 3, technicalScore: 2 },
      { value: "multiple_departments", label: "Multiple departments", solutionScore: 4, technicalScore: 3 },
      { value: "enterprise_wide", label: "Enterprise-wide impact", solutionScore: 5, technicalScore: 4 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "process_change",
    category: "Change Type & Business Impact",
    question: "Does this change require modifications to existing business processes?",
    options: [
      { value: "no_process_change", label: "No - Technical fix only, no process impact", solutionScore: 1, technicalScore: 4 },
      { value: "minor_process", label: "Minor - Small adjustments to existing processes", solutionScore: 3, technicalScore: 3 },
      { value: "significant_process", label: "Significant - Major process redesign required", solutionScore: 5, technicalScore: 3 },
      { value: "new_process", label: "New - Completely new business process", solutionScore: 5, technicalScore: 4 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },

  // Salesforce Clouds & Systems Impact (Questions 5-8)
  {
    id: "salesforce_clouds",
    category: "Salesforce Clouds & Systems Impact",
    question: "Which Salesforce clouds are impacted by this change?",
    options: [
      { value: "single_cloud", label: "Single cloud (Sales Cloud, Service Cloud, or Marketing Cloud only)", solutionScore: 2, technicalScore: 2 },
      { value: "sales_service", label: "Sales Cloud + Service Cloud integration", solutionScore: 3, technicalScore: 3 },
      { value: "cpq_integration", label: "CPQ with Sales Cloud or other clouds", solutionScore: 4, technicalScore: 4 },
      { value: "multiple_clouds", label: "3+ clouds (Sales, Service, Marketing, Community)", solutionScore: 5, technicalScore: 4 },
      { value: "ecosystem_wide", label: "Entire Salesforce ecosystem including Experience/Community Cloud", solutionScore: 5, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "external_systems",
    category: "Salesforce Clouds & Systems Impact",
    question: "Which external systems are impacted by this Salesforce change?",
    options: [
      { value: "no_external", label: "No external systems - Salesforce only", solutionScore: 2, technicalScore: 2 },
      { value: "single_system", label: "Single system (Oracle ERP, SAP, LBO, or Customer Portal)", solutionScore: 3, technicalScore: 4 },
      { value: "erp_systems", label: "ERP systems (Oracle ERP, SAP) with complex data flows", solutionScore: 4, technicalScore: 5 },
      { value: "multiple_systems", label: "Multiple systems (ERP + Portal + other business applications)", solutionScore: 5, technicalScore: 5 },
      { value: "legacy_complex", label: "Legacy systems requiring custom middleware/transformation", solutionScore: 4, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "business_processes",
    category: "Salesforce Clouds & Systems Impact",
    question: "Which core business processes are affected by this change?",
    options: [
      { value: "single_process", label: "Single process (Lead Management, Case Management, etc.)", solutionScore: 3, technicalScore: 2 },
      { value: "sales_processes", label: "Sales processes (Lead-to-Cash, Opportunity Management, CPQ)", solutionScore: 4, technicalScore: 3 },
      { value: "service_processes", label: "Service processes (Case-to-Resolution, Knowledge Management)", solutionScore: 4, technicalScore: 3 },
      { value: "cross_functional", label: "Cross-functional processes spanning Sales, Service, Marketing", solutionScore: 5, technicalScore: 4 },
      { value: "end_to_end", label: "End-to-end customer lifecycle (Marketing-to-Service)", solutionScore: 5, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "data_integration_scope",
    category: "Salesforce Clouds & Systems Impact",
    question: "What is the scope of data integration required across systems?",
    options: [
      { value: "no_integration", label: "No data integration - isolated change", solutionScore: 2, technicalScore: 1 },
      { value: "simple_sync", label: "Simple data sync between Salesforce and one system", solutionScore: 3, technicalScore: 3 },
      { value: "batch_sync", label: "Batch sync with scheduled data processing", solutionScore: 3, technicalScore: 3 },
      { value: "bi_directional", label: "Bi-directional sync with business logic transformation", solutionScore: 3, technicalScore: 4 },
      { value: "real_time", label: "Real-time integration with multiple systems", solutionScore: 4, technicalScore: 5 },
      { value: "complex_orchestration", label: "Complex data orchestration across clouds and external systems", solutionScore: 5, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },

  // Technical Complexity & Development (Questions 9-12)
  {
    id: "technical_scope",
    category: "Technical Complexity & Development",
    question: "What is the technical scope of the change?",
    options: [
      { value: "configuration_only", label: "Configuration only - Fields, workflows, reports", solutionScore: 3, technicalScore: 2 },
      { value: "basic_customization", label: "Basic customization - Simple triggers, basic flows", solutionScore: 2, technicalScore: 3 },
      { value: "complex_development", label: "Complex development - Advanced Apex, LWC, integrations", solutionScore: 2, technicalScore: 5 },
      { value: "architecture_change", label: "Architecture change - Data model, security model changes", solutionScore: 3, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "system_integration",
    category: "Technical Complexity & Development",
    question: "Does this change involve external system integrations?",
    options: [
      { value: "no_integration", label: "No external integrations required", solutionScore: 2, technicalScore: 1 },
      { value: "existing_integration", label: "Modify existing integration", solutionScore: 3, technicalScore: 4 },
      { value: "new_simple_integration", label: "New simple integration (REST/SOAP)", solutionScore: 3, technicalScore: 4 },
      { value: "complex_integration", label: "Complex integration with middleware/real-time sync", solutionScore: 4, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "data_impact",
    category: "Technical Complexity & Development",
    question: "What level of data changes are required?",
    options: [
      { value: "no_data_change", label: "No data changes required", solutionScore: 2, technicalScore: 1 },
      { value: "minor_data_update", label: "Minor data updates/cleanup", solutionScore: 2, technicalScore: 3 },
      { value: "data_migration", label: "Data migration between objects/systems", solutionScore: 3, technicalScore: 4 },
      { value: "data_model_change", label: "Data model changes affecting multiple objects", solutionScore: 4, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "incident_urgency",
    category: "Technical Complexity & Development",
    question: "If this is an incident, what is the urgency level?",
    options: [
      { value: "not_incident", label: "Not an incident", solutionScore: 0, technicalScore: 0 },
      { value: "p4_low", label: "P4 - Low priority, can wait for next release", solutionScore: 2, technicalScore: 2 },
      { value: "p3_medium", label: "P3 - Medium priority, fix in current sprint", solutionScore: 2, technicalScore: 3 },
      { value: "p2_high", label: "P2 - High priority, fix within 24-48 hours", solutionScore: 2, technicalScore: 4 },
      { value: "p1_critical", label: "P1 - Critical, immediate fix required", solutionScore: 1, technicalScore: 5 }
    ]
  },

  // Multi-Cloud & Solution Complexity (Questions 13-15)
  {
    id: "feature_complexity",
    category: "Multi-Cloud & Solution Complexity",
    question: "What Salesforce features are involved in this change?",
    options: [
      { value: "standard_features", label: "Standard features - Objects, fields, workflows", solutionScore: 3, technicalScore: 2 },
      { value: "advanced_features", label: "Advanced features - CPQ, Field Service, Communities", solutionScore: 4, technicalScore: 3 },
      { value: "platform_features", label: "Platform features - Lightning Platform, Experience Cloud", solutionScore: 4, technicalScore: 4 },
      { value: "custom_solutions", label: "Custom solutions requiring significant development", solutionScore: 3, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "user_experience",
    category: "Multi-Cloud & Solution Complexity",
    question: "Does this change impact user interface or user experience?",
    options: [
      { value: "no_ui_change", label: "No UI changes required", solutionScore: 2, technicalScore: 3 },
      { value: "minor_ui", label: "Minor UI modifications", solutionScore: 3, technicalScore: 3 },
      { value: "significant_ui", label: "Significant UI redesign", solutionScore: 4, technicalScore: 4 },
      { value: "custom_ui", label: "Custom UI components/Lightning Web Components", solutionScore: 3, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "security_impact",
    category: "Multi-Cloud & Solution Complexity",
    question: "Does this change affect security, permissions, or data access?",
    options: [
      { value: "no_security_change", label: "No security or permission changes", solutionScore: 2, technicalScore: 2 },
      { value: "minor_permission", label: "Minor permission adjustments", solutionScore: 3, technicalScore: 3 },
      { value: "role_hierarchy", label: "Role hierarchy or sharing rule changes", solutionScore: 4, technicalScore: 4 },
      { value: "complex_security", label: "Complex security model or compliance requirements", solutionScore: 4, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },

  // Project Management & Timeline (Questions 16-18)
  {
    id: "timeline_pressure",
    category: "Project Management & Timeline",
    question: "What is the timeline expectation for this change?",
    options: [
      { value: "immediate", label: "Immediate - Within hours", solutionScore: 1, technicalScore: 5 },
      { value: "urgent", label: "Urgent - Within days", solutionScore: 2, technicalScore: 4 },
      { value: "normal", label: "Normal - Within weeks", solutionScore: 3, technicalScore: 3 },
      { value: "planned", label: "Planned - Within months", solutionScore: 4, technicalScore: 3 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "testing_requirements",
    category: "Project Management & Timeline",
    question: "What level of testing is required for this change?",
    options: [
      { value: "minimal_testing", label: "Minimal - Quick validation only", solutionScore: 2, technicalScore: 3 },
      { value: "standard_testing", label: "Standard - Unit and integration testing", solutionScore: 3, technicalScore: 4 },
      { value: "comprehensive_testing", label: "Comprehensive - Full regression testing", solutionScore: 4, technicalScore: 4 },
      { value: "extensive_testing", label: "Extensive - User acceptance and performance testing", solutionScore: 5, technicalScore: 5 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  },
  {
    id: "change_management",
    category: "Project Management & Timeline",
    question: "What level of change management and training is needed?",
    options: [
      { value: "no_training", label: "No training - Transparent to users", solutionScore: 1, technicalScore: 2 },
      { value: "minimal_training", label: "Minimal - Email notification or quick demo", solutionScore: 2, technicalScore: 2 },
      { value: "standard_training", label: "Standard - Training sessions and documentation", solutionScore: 4, technicalScore: 2 },
      { value: "extensive_training", label: "Extensive - Comprehensive change management program", solutionScore: 5, technicalScore: 3 },
      { value: "not_applicable", label: "Not Applicable", solutionScore: 0, technicalScore: 0 }
    ]
  }
];

interface QuestionnaireFormProps {
  onBack: () => void;
}

export const QuestionnaireForm = ({ onBack }: QuestionnaireFormProps) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResults, setShowResults] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
  const isLastQuestion = currentQuestionIndex === questions.length - 1;

  const handleAnswerChange = (value: string) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: value
    }));
  };

  const handleNext = () => {
    if (isLastQuestion) {
      setShowResults(true);
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    setCurrentQuestionIndex(prev => prev - 1);
  };

  const canProceed = answers[currentQuestion.id];

  if (showResults) {
    return <QuestionnaireResults answers={answers} questions={questions} onRestart={() => {
      setShowResults(false);
      setCurrentQuestionIndex(0);
      setAnswers({});
    }} onBack={onBack} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={onBack}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Overview</span>
            </Button>
            <div className="text-sm text-gray-600">
              Question {currentQuestionIndex + 1} of {questions.length}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm text-gray-500">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center space-x-2 mb-2">
              <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                {currentQuestion.category}
              </span>
            </div>
            <CardTitle className="text-xl leading-relaxed">
              {currentQuestion.question}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup 
              value={answers[currentQuestion.id] || ""} 
              onValueChange={handleAnswerChange}
              className="space-y-4"
            >
              {currentQuestion.options.map((option) => (
                <div key={option.value} className="flex items-start space-x-3 p-4 rounded-lg border hover:bg-gray-50 transition-colors">
                  <RadioGroupItem value={option.value} id={option.value} className="mt-1" />
                  <Label htmlFor={option.value} className="text-base leading-relaxed cursor-pointer flex-1">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={handlePrevious}
            disabled={currentQuestionIndex === 0}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous</span>
          </Button>

          <Button 
            onClick={handleNext}
            disabled={!canProceed}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
          >
            <span>{isLastQuestion ? "View Results" : "Next"}</span>
            {isLastQuestion ? (
              <CheckCircle className="w-4 h-4" />
            ) : (
              <ArrowRight className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

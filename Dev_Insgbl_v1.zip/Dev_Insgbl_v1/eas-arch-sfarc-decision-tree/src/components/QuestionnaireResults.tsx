import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, RefreshCw, User, Code, CheckCircle, AlertTriangle, Info } from "lucide-react";

interface Question {
  id: string;
  category: string;
  question: string;
  options: { value: string; label: string; solutionScore: number; technicalScore: number; }[];
}

interface QuestionnaireResultsProps {
  answers: Record<string, string>;
  questions: Question[];
  onRestart: () => void;
  onBack: () => void;
}

export const QuestionnaireResults = ({ answers, questions, onRestart, onBack }: QuestionnaireResultsProps) => {
  const [showDetailedAnalysis, setShowDetailedAnalysis] = useState(false);

  // Calculate scores
  const calculateScores = () => {
    let solutionScore = 0;
    let technicalScore = 0;
    let totalQuestions = 0;

    questions.forEach(question => {
      const selectedAnswer = answers[question.id];
      if (selectedAnswer) {
        const option = question.options.find(opt => opt.value === selectedAnswer);
        if (option) {
          // Skip N/A answers for scoring
          if (option.solutionScore > 0 || option.technicalScore > 0) {
            solutionScore += option.solutionScore;
            technicalScore += option.technicalScore;
            totalQuestions++;
          }
        }
      }
    });

    return {
      solutionScore: totalQuestions > 0 ? (solutionScore / totalQuestions) : 0,
      technicalScore: totalQuestions > 0 ? (technicalScore / totalQuestions) : 0,
      totalQuestions
    };
  };

  const { solutionScore, technicalScore } = calculateScores();
  const scoreDifference = Math.abs(solutionScore - technicalScore);
  
  // Determine recommendation based on scores and patterns
  const getRecommendation = () => {
    if (scoreDifference < 0.5) {
      return {
        type: "Both Required",
        icon: CheckCircle,
        color: "bg-purple-600",
        badgeColor: "bg-purple-100 text-purple-800",
        description: "This change requires both Solution and Technical Architect expertise"
      };
    } else if (solutionScore > technicalScore) {
      return {
        type: "Solution Architect",
        icon: User,
        color: "bg-blue-600",
        badgeColor: "bg-blue-100 text-blue-800",
        description: "This change primarily requires Solution Architect leadership"
      };
    } else {
      return {
        type: "Technical Architect",
        icon: Code,
        color: "bg-green-600",
        badgeColor: "bg-green-100 text-green-800",
        description: "This change primarily requires Technical Architect expertise"
      };
    }
  };

  const recommendation = getRecommendation();
  const RecommendationIcon = recommendation.icon;

  // Get detailed analysis by category
  const getCategoryAnalysis = () => {
    const categories: Record<string, { solutionScore: number; technicalScore: number; count: number; }> = {};
    
    questions.forEach(question => {
      const selectedAnswer = answers[question.id];
      if (selectedAnswer) {
        const option = question.options.find(opt => opt.value === selectedAnswer);
        if (option && (option.solutionScore > 0 || option.technicalScore > 0)) {
          if (!categories[question.category]) {
            categories[question.category] = { solutionScore: 0, technicalScore: 0, count: 0 };
          }
          categories[question.category].solutionScore += option.solutionScore;
          categories[question.category].technicalScore += option.technicalScore;
          categories[question.category].count++;
        }
      }
    });

    return Object.entries(categories).map(([category, scores]) => ({
      category,
      solutionAvg: scores.count > 0 ? scores.solutionScore / scores.count : 0,
      technicalAvg: scores.count > 0 ? scores.technicalScore / scores.count : 0,
      count: scores.count
    }));
  };

  const categoryAnalysis = getCategoryAnalysis();

  // Updated recommendations for the PM context
  const getSpecificRecommendations = () => {
    if (recommendation.type === "Solution Architect") {
      return {
        primary: [
          "Lead business process analysis and stakeholder alignment across departments",
          "Design functional requirements and cross-cloud integration strategy", 
          "Establish change management processes and user training programs",
          "Guide business process optimization and workflow design"
        ],
        secondary: [
          "Consider Technical Architect consultation for complex custom development",
          "Engage technical expertise for integration and performance requirements",
          "Include TA in technical design reviews if custom code is involved"
        ]
      };
    } else if (recommendation.type === "Technical Architect") {
      return {
        primary: [
          "Lead technical implementation design and custom development",
          "Handle complex integrations, data migrations, and performance optimization",
          "Resolve production incidents and technical troubleshooting",
          "Establish technical governance and deployment processes"
        ],
        secondary: [
          "Include business stakeholders in functional requirement reviews",
          "Consider Solution Architect for complex business process changes",
          "Ensure alignment with overall business strategy and user adoption"
        ]
      };
    } else {
      return {
        primary: [
          "Solution Architect: Lead business strategy, process design, and stakeholder management",
          "Technical Architect: Handle technical implementation, integrations, and custom development",
          "Ensure close collaboration between both roles throughout the change lifecycle",
          "Establish clear responsibilities and communication protocols between SA and TA"
        ],
        secondary: [
          "This is a complex change requiring both business and technical expertise",
          "Budget for both architectural roles in your project planning",
          "Ensure both architects participate in key design and decision meetings"
        ]
      };
    }
  };

  const specificRecommendations = getSpecificRecommendations();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={onBack}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Overview</span>
            </Button>
            <Button 
              variant="outline" 
              onClick={onRestart}
              className="flex items-center space-x-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Assess Another Change</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Main Result */}
        <Card className="mb-8">
          <CardHeader className="text-center pb-6">
            <div className="flex justify-center mb-4">
              <div className={`w-20 h-20 ${recommendation.color} rounded-full flex items-center justify-center`}>
                <RecommendationIcon className="w-10 h-10 text-white" />
              </div>
            </div>
            <CardTitle className="text-3xl mb-2">Assessment Complete</CardTitle>
            <Badge className={`${recommendation.badgeColor} text-lg px-4 py-2 font-semibold`}>
              Recommended: {recommendation.type}
            </Badge>
            <p className="text-gray-600 mt-4 text-lg">
              {recommendation.description}
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="text-center p-6 bg-blue-50 rounded-lg">
                <div className="text-3xl font-bold text-blue-600 mb-2">
                  {solutionScore.toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">Solution Architect Score</div>
                <div className="text-xs text-gray-500 mt-1">Business & Process Focus</div>
              </div>
              <div className="text-center p-6 bg-green-50 rounded-lg">
                <div className="text-3xl font-bold text-green-600 mb-2">
                  {technicalScore.toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">Technical Architect Score</div>
                <div className="text-xs text-gray-500 mt-1">Technical & Implementation Focus</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Specific Recommendations */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Info className="w-5 h-5 text-blue-600" />
              <span>Project Manager Action Items</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Primary Responsibilities</span>
                </h4>
                <ul className="space-y-2">
                  {specificRecommendations.primary.map((item, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Separator />

              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                  <span>Additional Considerations</span>
                </h4>
                <ul className="space-y-2">
                  {specificRecommendations.secondary.map((item, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-orange-600 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Analysis Toggle */}
        <div className="text-center mb-6">
          <Button 
            variant="outline" 
            onClick={() => setShowDetailedAnalysis(!showDetailedAnalysis)}
            className="flex items-center space-x-2"
          >
            <span>{showDetailedAnalysis ? "Hide" : "Show"} Detailed Analysis</span>
          </Button>
        </div>

        {/* Category Breakdown */}
        {showDetailedAnalysis && (
          <Card>
            <CardHeader>
              <CardTitle>Category-by-Category Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {categoryAnalysis.map((category, index) => (
                  <div key={index} className="border-l-4 border-blue-200 pl-4">
                    <h4 className="font-semibold text-gray-900 mb-3">{category.category}</h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="flex justify-between items-center p-3 bg-blue-50 rounded">
                        <span className="text-sm text-gray-600">Solution Focus</span>
                        <span className="font-semibold text-blue-600">{category.solutionAvg.toFixed(1)}/5</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-green-50 rounded">
                        <span className="text-sm text-gray-600">Technical Focus</span>
                        <span className="font-semibold text-green-600">{category.technicalAvg.toFixed(1)}/5</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

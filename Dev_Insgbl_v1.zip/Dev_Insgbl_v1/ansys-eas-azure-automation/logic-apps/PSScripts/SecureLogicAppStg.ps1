<#
📜 PowerShell Script: Configure VNET, Private Endpoints & Storage Firewall for Logic Apps

🔹 What This Script Does?
This PowerShell script automates the integration of Azure Standard Logic Apps with a Virtual Network (VNET), 
sets up Private Endpoints (PLE) for Storage Accounts, and disables public access to storage while ensuring seamless network security.

✅ Key Features
✔ Supports All or Specific Logic Apps – Process all Logic Apps in a Resource Group or target a specific one.
✔ Ensures VNET & Subnet Exist – Validates the VNET and required subnets before proceeding.
✔ Configures Private Endpoints for Storage – Ensures Logic Apps use a Private Endpoint (PLE) for secure storage access.
✔ Disables Public Storage Access – Enhances security by restricting access to VNET-only.
✔ Handles Subnet Delegation – Checks and adds delegation for Logic Apps in the Microsoft.Web/serverFarms namespace.
✔ Auto-Restarts Logic Apps – Ensures changes take effect by stopping and restarting Logic Apps.

🖥️ Script Execution Guide
1️⃣ Prerequisites
Before running the script, ensure:
✔ You have the Az PowerShell Module installed:
✔ You are logged in to Azure:
✔ Your Logic Apps and VNET, Storage Account, and Subnets are correctly configured.
✔ You have Owner/Contributor permissions for Logic Apps, Networking, and Storage.

2️⃣ How to Execute the Script
------------------------------
Run for All Logic Apps in a Resource Group:-

.\script.ps1 -SubscriptionName "my-subscription" -ResourceGroupName "my-resource-group" -VnetName "my-vnet" -LogicAppSubnetName "logicapp-subnet" -PLESubnetName "ple-subnet" -logicAppName [press Enter]

🔹 Processes all Standard Logic Apps in the specified Resource Group

Run for a Specific Logic App

.\script.ps1 -SubscriptionName "my-subscription" -ResourceGroupName "my-resource-group" -VnetName "my-vnet" -LogicAppSubnetName "logicapp-subnet" -PLESubnetName "ple-subnet" -logicAppName "my-logic-app"

🔹 Applies changes only to the specified Logic App

📌 Parameter Explanation
 Parameter	        Description	                                                        Mandatory?
 ---------          ------------------------------                                      --------
-SubscriptionName	Azure subscription name to use.	                                    ✅ Yes
-ResourceGroupName	Name of the Resource Group containing the Logic Apps.	            ✅ Yes
-VnetName	        Name of the VNET to integrate with.	                                ✅ Yes
-LogicAppSubnetName	Subnet within the VNET for Logic Apps.	                            ✅ Yes
-PLESubnetName	    Subnet within the VNET for Private Endpoints.	                    ✅ Yes
-logicAppName	    Specific Logic App to configure. Leave blank to process all.	    ✅ Yes

#>
param (
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionName,      # Accepts one subscription names

    [Parameter(Mandatory = $true)]
    [string]$ResourcegroupName,     # Mandatory parameter for Resource group

    [Parameter(Mandatory = $true)]
    [string]$VnetName,              # Mandatory parameter for Parent VNET Name

    [Parameter(Mandatory = $true)]
    [string]$LogicAppSubnetName,    # Mandatory parameter for Logic App Subnet Name

    [Parameter(Mandatory = $true)]
    [string]$PLESubnetName,          # Mandatory parameter for private endpoint Subnet Name

    [Parameter(Mandatory = $true)]
    [AllowEmptyString()]
    [string]$logicAppName           # Press Enter to provide blank for processing all otherwise give logic name for specific
)

# Enable Error Handling
$ErrorActionPreference = "Stop"

# Set the active subscription
$subscription = Get-AzSubscription | Where-Object { $_.Name -eq $SubscriptionName }
if (-not $subscription) {
    Write-Warning "Subscription '$($SubscriptionName)' not found. Skipping..."
    continue
}

Write-Host "Processing subscription: $($SubscriptionName) and ResourceGroup: $($ResourcegroupName)" -ForegroundColor Green

# Define subscription ID
$subscriptionId = $subscription.Id

$regionMap = @{}
Get-AzLocation | ForEach-Object { $regionMap[$_.DisplayName] = $_.Location }

# ✅ Step-1: Get VNET and Subnet details in the same region
$vnet = Get-AzVirtualNetwork | Where-Object { $_.Name -eq $VnetName }
if (-not $vnet) {
    throw "VNet '$VnetName' not found in region '$location'. Skipping Logic App $($logicApp.Name)......"
    exit
}
else {
    Write-Host "VNet '$VnetName' found." -ForegroundColor Blue
}

$PEsubnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $PLEsubnetName
if (-not $PEsubnet) {
    throw "❌ Private endpoint Subnet '$PLEsubnetName' not found in VNet $VnetName. Ensure it's not delegated to anything."
    exit
}
else {
    Write-Host "Private endpoint Subnet '$PLEsubnetName' found." -ForegroundColor Blue
}

$LappSubnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $LogicAppSubnetName
if (-not $LappSubnet) { 
    throw "❌ Logic App Subnet '$LogicAppSubnetName' not found in VNET '$VnetName'. Ensure it's delegated to 'Microsoft.Web/logicApps'"
}
else {
    Write-Host "Logic App Subnet '$LogicAppSubnetName' found." -ForegroundColor Blue
}

# ✅ Step 2: Now Get all Standard Logic Apps in the resource group
$logicApps = Get-AzWebApp -ResourceGroupName $ResourcegroupName | Where-Object { 
    $_.Kind -eq "Stateful" -or $_.Kind -eq "Stateless" -or $_.Kind -eq "functionapp,workflowapp"
}

if ($logicApps.Count -eq 0) {
    Write-Host "No Standard Logic Apps found in resource group: $ResourcegroupName" -ForegroundColor Red
    exit
}
else {
    Write-Host "Total Logic App found:- $($logicApps.Count) in Resource Group '$($ResourcegroupName)'" -ForegroundColor DarkMagenta
}

# If a specific Logic App is provided, filter the list
if ($logicAppName -ne "" -and -not [string]::IsNullOrWhiteSpace($logicAppName)) {

    Write-Host "But Processing for a specefic Logic App '$($logicAppName)'....." -ForegroundColor Yellow

    $logicApps = $logicApps | Where-Object { $_.Name -eq $logicAppName }
    if (-not $logicApps) {
        Write-Host "Logic App '$($logicAppName)' not found in Resource Group '$($ResourcegroupName)'. Please give correct one." -ForegroundColor Red
        exit 1
    }
}

# ✅ Step 3: Process each Logic App
foreach ($logicApp in $logicApps) {
    Write-Host "Processing Logic App: $($logicApp.Name)" -ForegroundColor Green

    # Dynamically get Logic App's region
    $location = $regionMap[$logicApp.Location]
    Write-Host "Logic App Location is: $location ($($logicApp.Location))" -ForegroundColor Blue    

    # Get storage account from Logic App app settings
    $appSettings = (Get-AzWebApp -ResourceGroupName $ResourcegroupName -Name $logicApp.Name).SiteConfig.AppSettings
    $storageAccountName = ($appSettings | Where-Object { 
            $_.Name -eq "AzureWebJobsStorage" 
        }).Value -replace "^.*AccountName=([^;]+);.*$", '$1'

    if (-not $storageAccountName) {
        Write-Host "No associated storage account found for Logic App: $($logicApp.Name) OR you don't have Read/Write permission to settings" -ForegroundColor Red
        exit
    }
    else {
        Write-Host "Associated storage account name:- $($storageAccountName)"
    }

    # Get storage account details
    $storageAccount = Get-AzStorageAccount | Where-Object { $_.StorageAccountName -eq $storageAccountName }
    if (-not $storageAccount) {
        Write-Host "Storage account $storageAccountName not found in the Resource group." -ForegroundColor Red
        continue
    }

    Write-Host "Found storage account in the Resource group: $storageAccountName" -ForegroundColor Green

    # ✅ Step 4: Checking and if not found Creating PLE for the storage
    $privateEndpointName = "$($storageAccount.StorageAccountName)-pe"

    # Fetch all Private Endpoints in the Resource Group
    $privateEndpoints = Get-AzPrivateEndpoint -ResourceGroupName $ResourcegroupName

    # Find Private Endpoint associated with the Storage Account
    $pe = $privateEndpoints | Where-Object { $_.Name -eq $privateEndpointName }

    # Check if private endpoint exists
    $existingPrivateEndpoint = $pe.PrivateLinkServiceConnections | Where-Object { $_.PrivateLinkServiceId -eq $storageAccount.Id }

    if ($null -ne $existingPrivateEndpoint -and $existingPrivateEndpoint.PrivateLinkServiceConnectionState.Status -ne "Disconnected") {
        Write-Host "Private endpoint '$($storageAccount.StorageAccountName)-pe' already exists for $storageAccountName. Skipping....." -ForegroundColor Yellow
    }
    else {
        Write-Host "Private endpoint '$($storageAccount.StorageAccountName)-pe' doesn't exists. Creating.........."

        try {  
            # Determine the correct GroupId based on the storage account type
            $storageType = $storageAccount.Kind  # Example: "StorageV2", "BlobStorage"
            $groupId = switch ($storageType) {
                "StorageV2" { "blob" }  # Most common case
                "BlobStorage" { "blob" }
                "FileStorage" { "file" }
                "TableStorage" { "table" }
                "QueueStorage" { "queue" }
                default { "blob" }  # Default to "blob" if unknown
            }

            # If the PLE is in "Disconnected" state then deleting first
            if ($null -ne $existingPrivateEndpoint -and $existingPrivateEndpoint.PrivateLinkServiceConnectionState.Status -eq "Disconnected") {

                Write-Host "Private Endpoint '$($privateEndpointName)' is in a DISCONNECTED state. Deleting it..." -ForegroundColor Yellow

                # Delete the Private Endpoint
                Remove-AzPrivateEndpoint -ResourceGroupName $ResourcegroupName -Name $privateEndpointName -Force

                Write-Host "Deleted Private Endpoint '$privateEndpointName'." -ForegroundColor Yellow

                Start-Sleep -Seconds 10  # Wait for deletion to complete
            }

            # Create a Private Endpoint in the Logic App's region (use internal region name)
            $plsConnection= New-AzPrivateLinkServiceConnection -Name "$($privateEndpointName)-connection" `
                            -PrivateLinkServiceId $storageAccount.Id `
                            -GroupId $groupId `
                            -RequestMessage 'Please Approve'

            New-AzPrivateEndpoint -Name "$($privateEndpointName)" -ResourceGroupName $ResourcegroupName `
            -Location $location -PrivateLinkServiceConnection $plsConnection -Subnet $PEsubnet -Force

            Write-Host "Created Private Endpoint successfully: $privateEndpointName" -ForegroundColor Green

        }
        catch {
            Write-Error "Failed to proceed. Error details: $($_.Exception.Message)"
            exit
        }        
    }

    # ✅ Step 5: Disable Public Access to Storage Account
    Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $storageAccount.ResourceGroupName `
                                    -Name $storageAccount.StorageAccountName -DefaultAction Deny

    Write-Host "Public access succesfully disabled for: $($storageAccount.StorageAccountName)" -ForegroundColor Green

    # ✅ Step 6: If not already added then adding existing logic app subnet to the storage
    $storageRules = Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $ResourcegroupName -Name $storageAccount.StorageAccountName
    $existingRule = $storageRules.VirtualNetworkRules | Where-Object { $_.VirtualNetworkResourceId -eq $LappSubnet.Id }

    if ($existingRule) {
        Write-Host "VNET '$VnetName' with Subnet '$($LappSubnet.Name)' is already added to Storage($($storageAccount.StorageAccountName)) Firewall. Skipping....." -ForegroundColor Yellow
    } else {
        Write-Host "Adding existing Logic app Subnet($($LappSubnet.Name)) to Storage Firewall..." -ForegroundColor Yellow

        Add-AzStorageAccountNetworkRule -ResourceGroupName $ResourcegroupName -Name $storageAccount.StorageAccountName `
                                        -VirtualNetworkResourceId $LappSubnet.Id

        Write-Host "Sucessfully Added Logic App subnet to Storage Firewall." -ForegroundColor Green
    }

    # ✅ STEP 7: Ensure Logic App is integrated with VNET, If not then adding
    if($null -eq $logicApp.VirtualNetworkSubnetId) {

        Write-Host "Logic App is not integrated with VNET. Adding integration now..." -ForegroundColor Yellow

        #check if logic app subnet has delegation or not
        $isdelegated = Get-AzDelegation -Subnet $LappSubnet

        if($isdelegated.Name -eq "delegation" -and $isdelegated.ServiceName -eq "Microsoft.Web/serverFarms")
        {
            Write-Host "Logic App Subnet is already delegated. Proceeding with VNet integration now..." -ForegroundColor Green
        }
        else {
            Write-Host "Logic App Subnet is not delegated to 'Microsoft.Web/serverFarms'. Adding delegation now..." -ForegroundColor Yellow

            $LappDelegatedSubnet = Add-AzDelegation -Name "LappDelegation" -ServiceName "Microsoft.Web/serverFarms" -Subnet $LappSubnet
            Set-AzVirtualNetwork -VirtualNetwork $vnet
        }

        $subnetResourceId = "/subscriptions/$subscriptionId/resourceGroups/$ResourcegroupName/providers/Microsoft.Network/virtualNetworks/$($vnet.Name)/subnets/$($LappSubnet.Name)"
        $webApp = Get-AzResource -ResourceType Microsoft.Web/sites -ResourceGroupName $ResourcegroupName -ResourceName $logicApp.Name
        $webApp.Properties.virtualNetworkSubnetId = $subnetResourceId
        $webApp.Properties.vnetRouteAllEnabled = 'true'
        $webApp | Set-AzResource -Force
        
        Write-Host "Logic App VNET($($LappSubnet.Name)) integration completed succesfully!" -ForegroundColor Green

    } else {
        Write-Host "Logic App is already integrated with VNET. Skipping...." -ForegroundColor Yellow
        continue
    }

    Write-Host "Succesfully Updated Logic App '$($logicApp.Name)' to use the Vnet Integration and private endpoint" -ForegroundColor Green

    # ✅ STEP 8: Restart Logic App to apply changes
    Stop-AzWebApp -ResourceGroupName $ResourceGroupName -Name $logicApp.Name
    Start-AzWebApp -ResourceGroupName $ResourceGroupName -Name $logicApp.Name

    Write-Host "Restarted Logic App '$($logicApp.Name)' to apply changes" -ForegroundColor Green
}

Write-Host "✅ All Logic Apps updated with private storage endpoints!" -ForegroundColor Green

# Azure Logic App Consumption Deployment

This repository provides a reusable Infrastructure-as-Code (IaC) solution to deploy Azure Logic App **Consumption** workflows using a Bicep module (`main.bicep`), a standardized wrapper pipeline (`logic-app-consumption.yaml`), and a calling pipeline (`lappcon-csm-snow-http-v1-iac.yaml`). The deployment supports parameterized environments using YAML-based variable files.

## Table of Contents

- [Overview](#overview)
- [What Can Be Deployed](#what-can-be-deployed)
- [Reusability](#reusability)
- [Prerequisites](#prerequisites)
- [Module: main.bicep](#module-mainbicep)
  - [Parameters](#parameters)
  - [Outputs](#outputs)
- [Pipeline: logic-app-consumption.yaml](#pipeline-logic-app-consumptionyaml)
  - [Role as Wrapper](#role-as-wrapper)
- [Calling Pipeline (IaC Pipeline)](#calling-pipeline-iac-pipeline)
  - [Calling Pipeline Code](#calling-pipeline-code)
- [Procedure to Create a New Calling Pipeline](#procedure-to-create-a-new-calling-pipeline)
  - [Folder Structure](#folder-structure)
  - [Steps to Create a New Calling Pipeline](#steps-to-create-a-new-calling-pipeline)
- [Variable File](#variable-file)
- [Implementation Guide](#implementation-guide)
- [Troubleshooting](#troubleshooting)
- [Notes](#notes)
- [Resources](#resources)

## Overview

The `main.bicep` module defines the Logic App (Consumption) workflow infrastructure. The `logic-app-consumption.yaml` wrapper pipeline handles deployment logic, while the `lappcon-csm-snow-http-v1-iac.yaml` calling pipeline triggers the deployment per environment, loading values from a YAML variable file such as `sbox.yaml`.

## What Can Be Deployed

- Azure Logic App Consumption (workflow)
- App configuration (runtime settings)
- Integration with Azure services
- System-assigned or user-assigned identity
- Diagnostic settings (if applicable)
- Tags for governance and tracking

## Reusability

- **Wrapper Pipeline**: `logic-app-consumption.yaml` is reusable across all environments.
- **Calling Pipeline**: Customize the `lappcon-csm-snow-http-v1-iac.yaml` pipeline for new projects or environments.
- **Environment Configs**: Use individual variable files like `sbox.yaml`, `dev.yaml`, etc., for multi-environment support.

## Prerequisites

- Azure Subscription with Contributor and User Access Administrator permissions
- Azure DevOps project with:
  - A configured service connection
  - A valid agent pool with Azure CLI, Bicep CLI, and PowerShell
- Pre-provisioned resource group
- Optional: Log Analytics workspace for diagnostics

## Module: main.bicep

Defines Logic App Consumption configuration.

### Parameters

| Parameter             | Type   | Required | Description |
|-----------------------|--------|----------|-------------|
| `logicAppName`        | string | Yes      | Name of the Logic App resource |
| `location`            | string | Yes      | Azure region |
| `resourceGroupName`   | string | Yes      | Target resource group |
| `identity`            | object | No       | Managed identity settings |
| `workflowDefinition`  | object | Yes      | Logic App definition object (workflow JSON) |
| `workflowParameters`  | object | No       | Logic App parameter object |
| `tags`                | object | No       | Resource tags |

### Outputs

| Output              | Type   | Description                           |
|---------------------|--------|---------------------------------------|
| `logicAppName`     | string | Name of the deployed Logic App        |
| `resourceId`       | string | Resource ID of the Logic App          |
| `location`         | string | Region where Logic App is deployed    |

## Pipeline: logic-app-consumption.yaml

### Role as Wrapper

This pipeline:

- Accepts inputs from the calling pipeline and variable files
- Validates and deploys Logic App using `main.bicep`
- Performs deployment using `az deployment group create`
- Requires **no code changes** when reused

## Calling Pipeline (IaC Pipeline)

The `lappcon-csm-snow-http-v1-iac.yaml` file coordinates the Logic App deployment process:

- Loads environment-specific variables
- Resolves identity and diagnostic dependencies (if applicable)
- Triggers the wrapper pipeline to deploy Logic App resources

### Calling Pipeline Code

> Path: `infra/logic-app-consumption/v1/lappcon-csm-snow-http-v1-iac.yaml`

## Procedure to Create a New Calling Pipeline

### Folder Structure

```
eas-azure-iac-core-pipeline/
├── infra/
│ ├── logic-app-consumption/
│ │ ├── v1/
│ │ │ └── lappcon-csm-snow-http-v1-iac.yaml
│ │ ├── variables/
│ │ │ ├── sbox.yaml
│ │ │ ├── dev.yaml
│ │ │ ├── test.yaml
│ │ │ └── prod.yaml
```

### Steps to Create a New Calling Pipeline

1. **Create Pipeline File**
   - Duplicate `lappcon-csm-snow-http-v1-iac.yaml` for your new service.
   - Adjust Logic App name, environment name, and wrapper reference as needed.

2. **Add Variable File**
   - Navigate to `infra/logic-app-consumption/variables/`
   - Copy `sbox.yaml` and rename to `dev.yaml`, `test.yaml`, etc.
   - Update values specific to the environment.

3. **Link to DevOps Pipeline**
   - In Azure DevOps, use the new YAML file in a pipeline
   - Set parameters like `targetEnvironment`, `pipeline_branch`, and `deployAction`

4. **Test and Validate**
   - Run the pipeline and confirm deployment in Azure Portal
   - Verify Logic App status and configuration

## Variable File

Example `sbox.yaml`:

```yaml
variables:
  environment: sbox
  AZURE_SUBSCRIPTION: azure-sc-logicapp-nonprod-v2
  resourceGroupName: rg-eas-logic-sbox-eastus
  location: eastus
  logicAppName: la-sbox-consumption-snow
  identity:
    type: SystemAssigned
  workflowDefinition: $(System.DefaultWorkingDirectory)/workflows/main.workflow.json
  workflowParameters:
    triggerName: myTrigger
    serviceUrl: https://example.com/api
  tags:
    Environment: sandbox
    CreatedBy: eas-devops@ansys.com
```

## Implementation Guide

### 1. Set Up Azure DevOps

- Create a service connection (`AZURE_SUBSCRIPTION`) with **Contributor** and **User Access Administrator** roles.
- Ensure the pipeline agent has the following tools installed:
  - Azure CLI
  - Bicep CLI
  - PowerShell Core
- Import or reference the core IaC library that includes:
  - `main.bicep`
  - `logic-app-consumption.yaml` (wrapper pipeline)

### 2. Prepare Variable Files

- Navigate to `infra/logic-app-consumption/variables/`
- Create environment-specific files: `sbox.yaml`, `dev.yaml`, `test.yaml`, etc.
- Populate the file with:
  - `logicAppName`
  - `resourceGroupName`
  - `workflowDefinition` (path to workflow JSON)
  - `workflowParameters` (optional key-value pairs)
  - `identity` settings
  - Optional diagnostic settings and tags

### 3. Configure and Run the Calling Pipeline

- Go to Azure DevOps > Pipelines > New Pipeline
- Select repository and choose `lappcon-csm-snow-http-v1-iac.yaml`
- On execution:
  - Set `targetEnvironment` to match your variable file (e.g., `sbox`)
  - Choose `deployAction` as `deploy` or `delete`

### 4. Post-Deployment Validation

- Navigate to the Azure Portal
- Confirm the Logic App is:
  - Deployed in the correct resource group and region
  - Visible in the Logic App designer
  - Using correct triggers and managed identity
  - Tagged appropriately for cost/governance

## Troubleshooting

| Issue                        | Cause / Resolution                                                                 |
|-----------------------------|-------------------------------------------------------------------------------------|
| Logic App not created        | Ensure `logicAppName` is globally unique and correctly referenced in YAML.        |
| Identity not assigned        | Confirm that identity type is specified (`SystemAssigned` or `UserAssigned`).     |
| Deployment fails on parameters | Check for typos or missing keys in the `workflowParameters` block.                |
| Storage or region mismatch   | Ensure the `location` and `resourceGroupName` are aligned with existing resources. |
| Invalid workflow definition  | Ensure that `workflowDefinition` is valid JSON and accessible at runtime.         |
| Wrapper or module not found  | Check core library paths and repository references.                               |
| Access denied errors         | Ensure service connection has sufficient permissions on the resource group.       |


## Notes

- This deployment template is for **Logic App Consumption**, not Standard.
- Workflow content is passed using the `workflowDefinition` object, which should be a valid ARM-compliant JSON.
- You can parameterize workflow inputs using `workflowParameters` in the YAML.
- Tags like `Environment`, `Application`, `CreatedBy`, etc., are highly recommended for all environments.
- Use a unique `logicAppName` per environment to avoid global name conflicts.
- If enabling diagnostics, ensure Log Analytics or other endpoints are correctly configured.
- Run deployments from a hosted or self-hosted DevOps agent with the required tooling.


## Resources

- [Azure Logic Apps (Consumption) Overview](https://learn.microsoft.com/en-us/azure/logic-apps/logic-apps-overview)
- [ARM Template Reference for Logic Apps](https://learn.microsoft.com/en-us/azure/templates/microsoft.logic/workflows)
- [Bicep Documentation](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [Azure DevOps YAML Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/yaml-schema/)
- [Using Managed Identities](https://learn.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/)
- [Azure Resource Manager Deployments](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/deploy-pipelines)

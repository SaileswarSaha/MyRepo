# Azure Logic App Standard Deployment

This repository provides a reusable Infrastructure-as-Code (IaC) solution to deploy Azure Logic App Standard using a Bicep module (`main.bicep`), a wrapper deployment pipeline (`logic-app-standard.yaml`), and an orchestrating calling pipeline (`lappstd-csm-snow-http-v1-iac.yaml`). It is optimized for multi-environment deployments with environment-specific variable files.

## Table of Contents

- [Overview](#overview)
- [What Can Be Deployed](#what-can-be-deployed)
- [Reusability](#reusability)
- [Prerequisites](#prerequisites)
- [Module: main.bicep](#module-mainbicep)
  - [Parameters](#parameters)
  - [Outputs](#outputs)
- [Pipeline: logic-app-standard.yaml](#pipeline-logic-app-standardyaml)
  - [Role as Wrapper](#role-as-wrapper)
- [Calling Pipeline (IaC Pipeline)](#calling-pipeline-iac-pipeline)
  - [Calling Pipeline Code](#calling-pipeline-code)
- [Procedure to Create a New Calling Pipeline](#procedure-to-create-a-new-calling-pipeline)
  - [Folder Structure](#folder-structure)
  - [Steps to Create a New Calling Pipeline](#steps-to-create-a-new-calling-pipeline)
- [Variable File](#variable-file)
- [Implementation Guide](#implementation-guide)
- [Troubleshooting](#troubleshooting)
- [Notes](#notes)
- [Resources](#resources)

## Overview

The `main.bicep` module defines the Azure Logic App Standard infrastructure including app settings, identity, networking, and hosting configurations. The `logic-app-standard.yaml` wrapper pipeline encapsulates the deployment logic, and the `lappstd-csm-snow-http-v1-iac.yaml` calling pipeline manages environment-specific deployments using the `sbox.yaml` variable file.

## What Can Be Deployed

- Azure Logic App Standard resource
- System- or user-assigned managed identity
- App settings and configuration
- Diagnostic settings for monitoring
- Virtual Network integration via private endpoints
- Hosting plan (App Service Plan)
- Deployment via Bicep and DevOps pipelines

## Reusability

- **Static Wrapper**: The `logic-app-standard.yaml` pipeline does not need modification.
- **Dynamic IaC**: Customize the calling pipeline and variable files for different environments.
- **Environment Isolation**: Easily extendable to dev, test, and prod environments via separate YAML variable files.

## Prerequisites

- Azure Subscription with Contributor and User Access Administrator roles
- Azure DevOps project with:
  - Service connection (`AZURE_SUBSCRIPTION`)
  - Agent pool with required tools (Azure CLI, PowerShell, Bicep CLI)
- Pre-created resource group and virtual network (if using VNet integration)
- Core IaC library containing the wrapper pipeline and Bicep module

## Module: main.bicep

The Bicep file defines the Logic App Standard deployment.

### Parameters

| Parameter             | Type   | Required | Description |
|-----------------------|--------|----------|-------------|
| `logicAppName`       | string | Yes      | Name of the Logic App. |
| `location`           | string | Yes      | Azure region. |
| `appServicePlanId`   | string | Yes      | Resource ID of the hosting App Service Plan. |
| `storageAccountName` | string | Yes      | Storage account used by Logic App. |
| `vnetIntegration`    | object | No       | Configuration for VNet and subnet. |
| `appSettings`        | object | No       | Key-value pairs for Logic App settings. |
| `identity`           | object | No       | System- or user-assigned identity config. |
| `diagnosticSettings` | array  | No       | Log and metric configuration. |
| `tags`               | object | No       | Resource metadata. |

### Outputs

| Output            | Type   | Description                       |
|-------------------|--------|-----------------------------------|
| `logicAppName`   | string | Deployed Logic App name.          |
| `resourceId`     | string | Azure Resource ID of Logic App.   |
| `location`       | string | Deployment location.              |

## Pipeline: logic-app-standard.yaml

### Role as Wrapper

This pipeline:

- Validates and deploys `main.bicep` using `az deployment group`
- Passes parameters from the calling pipeline dynamically
- Requires **no changes** between environments

## Calling Pipeline (IaC Pipeline)

The `lappstd-csm-snow-http-v1-iac.yaml` pipeline orchestrates Logic App Standard deployment by:

- Loading variables from `sbox.yaml`
- Installing prerequisites (CLI tools, extensions)
- Deploying dependencies (if any)
- Invoking the wrapper pipeline

### Calling Pipeline Code

> See `infra/logic-app-standard/v1/lappstd-csm-snow-http-v1-iac.yaml` for implementation.

## Procedure to Create a New Calling Pipeline

To onboard a new Logic App environment:

### Folder Structure

```
eas-azure-iac-core-pipeline/
├── infra/
│ ├── logic-app-standard/
│ │ ├── v1/
│ │ │ └── lappstd-csm-snow-http-v1-iac.yaml
│ │ ├── variables/
│ │ │ ├── sbox.yaml
│ │ │ ├── dev.yaml
│ │ │ ├── test.yaml
│ │ │ └── prod.yaml
```


### Steps to Create a New Calling Pipeline

1. **Create Pipeline File**
   - Duplicate the YAML pipeline and adjust `pipeline_branch`, `logicAppName`, etc.

2. **Add Variable File**
   - Create a new `variables/<env>.yaml` file.
   - Set `logicAppName`, `resourceGroupName`, `location`, identity, and plan IDs.

3. **Configure Azure DevOps**
   - Link to the repository path of your new pipeline.
   - Ensure the service connection has proper roles.

4. **Test**
   - Trigger pipeline with `deployAction: deploy`.
   - Monitor deployment and verify Logic App in Azure portal.

## Variable File

The `sbox.yaml` contains:

```yaml
variables:
  environment: sandbox
  AZURE_SUBSCRIPTION: azure-sc-logicapp-nonprod-v2
  resourceGroupName: rg-eas-logic-sbox-eastus
  location: eastus
  logicAppName: la-sbox-snow-int
  appServicePlanId: /subscriptions/<sub-id>/resourceGroups/rg-name/providers/Microsoft.Web/serverfarms/plan-name
  storageAccountName: stlogicsboxeastus
  appSettings:
    AzureWebJobsStorage: <connection-string>
    FUNCTIONS_EXTENSION_VERSION: ~4
  identity:
    type: SystemAssigned
  tags:
    Environment: sandbox
    CreatedBy: eas-devops@ansys.com
```

## Implementation Guide

### 1. Set Up Azure DevOps

- Create a service connection (`AZURE_SUBSCRIPTION`) with Contributor and User Access Administrator roles.
- Ensure the pipeline agent has Azure CLI, Bicep CLI, PowerShell Core, and necessary extensions installed.
- Import or link to the core IaC library containing:
  - `main.bicep`
  - `logic-app-standard.yaml` wrapper pipeline

### 2. Prepare Variable Files

- Navigate to `infra/logic-app-standard/variables/`
- Create a YAML variable file for each environment (e.g., `sbox.yaml`, `dev.yaml`)
- Configure required variables:
  - `logicAppName`
  - `resourceGroupName`
  - `location`
  - `appServicePlanId`
  - `appSettings`
  - `identity`
  - Optional: `diagnosticSettings`, `vnetIntegration`, `tags`

### 3. Configure and Run the Calling Pipeline

- Navigate to `infra/logic-app-standard/v1/`
- Use or duplicate `lappstd-csm-snow-http-v1-iac.yaml`
- Configure the following:
  - `targetEnvironment`: e.g., `sbox`
  - `pipeline_branch`: your IaC library branch
  - `deployAction`: `deploy` or `delete`

- Run the pipeline via Azure DevOps and monitor job outputs.

### 4. Post-Deployment Validation

- Check the Logic App in the Azure portal.
- Confirm:
  - The app is running under the correct App Service Plan.
  - App settings have been applied.
  - Identity and diagnostic settings are configured.
  - VNet integration (if used) is operational.

---

## Troubleshooting

| Issue                         | Possible Cause & Resolution |
|-------------------------------|-----------------------------|
| **Logic App not created**     | Ensure `logicAppName` is unique and properly formatted. |
| **App Service Plan issues**   | Verify that `appServicePlanId` points to a valid hosting plan. |
| **Identity assignment fails** | Confirm that identity settings (`SystemAssigned` or `UserAssigned`) are valid and correct. |
| **Storage account error**     | Validate `storageAccountName` exists and is accessible from the resource group and region. |
| **Diagnostic settings fail**  | Ensure Log Analytics workspace exists and the agent has proper role permissions. |
| **Variable not found error**  | Double-check `sbox.yaml` for typos or missing keys. |
| **Wrapper path issues**       | Verify the `logic-app-standard.yaml` path in the core library reference is correct. |

---

## Notes

- The `logic-app-standard.yaml` wrapper pipeline should not be modified. All customization is handled via the calling pipeline and environment variable files.
- Keep Logic App names unique per environment to avoid conflicts.
- Use meaningful tags such as `Environment`, `CreatedBy`, `Application`, and `CostCenter` for governance and reporting.
- This solution supports Logic App **Standard**, not **Consumption**.
- For production, consider enabling VNet integration and diagnostics.
- Diagnostic settings may require Log Analytics or Event Hub configurations.
- Azure CLI version 2.30+ is recommended for full Bicep support.

---

## Resources

- [Azure Logic Apps Documentation](https://learn.microsoft.com/en-us/azure/logic-apps/)
- [Azure Bicep Documentation](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
- [Azure DevOps YAML Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/yaml-schema/)
- [Private Endpoints for Logic Apps](https://learn.microsoft.com/en-us/azure/logic-apps/logic-apps-private-endpoint)
- [Managed Identities](https://learn.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/)
- [Azure Monitor Diagnostic Settings](https://learn.microsoft.com/en-us/azure/azure-monitor/essentials/diagnostic-settings)


